/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch;

/**
 *
 * @author Nigel
 */
public enum ChangeEvent {
	NEW_DIALOG,
	INITIALIZED,
	CANVAS_UPDATE,
	HISTORY_UPDATE,
	TIMEFRAME_UPDATE,
	PROJECT_CHANGED,
	COLOR_UPDATE
}
