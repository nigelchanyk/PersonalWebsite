/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.exceptions;

/**
 *
 * @author Nigel
 */
public class TypeMismatchException extends RuntimeException {
	public TypeMismatchException(Class givenType, Class expectedType) {
		super("Expecting type " + expectedType.getName() + ", but received " + givenType.getName());
	}	
}
