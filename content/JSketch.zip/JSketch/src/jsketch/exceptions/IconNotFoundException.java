/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.exceptions;

/**
 *
 * @author Nigel
 */
public class IconNotFoundException extends RuntimeException {
	
	public IconNotFoundException(String fileName) {
		super("Cannot find icon: " + fileName);
	}
	
}
