/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.exceptions;

/**
 *
 * @author Nigel
 */
public class InvalidTimeFrameException extends RuntimeException {
	
	public InvalidTimeFrameException(int givenTimeFrame, int acceptableTimeFrame) {
		super("Given time frame is invalid: " + givenTimeFrame + " (expecting time frame equal or after " + acceptableTimeFrame + ".");
	}
	
}
