/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.dialogs;

/**
 *
 * @author Nigel
 */
public class ConfirmDialogResponse extends AbstractDialogResponse {
	
	private int option;
	
	public ConfirmDialogResponse(AbstractDialogRequest request, int option) {
		super(request);
		this.option = option;
	}

	public int getOption() {
		return option;
	}

}
