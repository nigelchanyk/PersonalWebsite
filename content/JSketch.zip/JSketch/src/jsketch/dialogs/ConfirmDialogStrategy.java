/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.dialogs;

import javax.swing.JOptionPane;
import jsketch.exceptions.TypeMismatchException;

/**
 *
 * @author Nigel
 */
public abstract class ConfirmDialogStrategy extends AbstractDialogStrategy {

	@Override
	public void execute(AbstractDialogResponse response) {
		if (!(response instanceof ConfirmDialogResponse))
			throw new TypeMismatchException(response.getClass(), ConfirmDialogResponse.class);

		ConfirmDialogResponse optionResponse = (ConfirmDialogResponse)response;
		switch (optionResponse.getOption()) {
			case JOptionPane.YES_OPTION:
				yes();
				return;
			case JOptionPane.NO_OPTION:
				no();
				return;
			case JOptionPane.CANCEL_OPTION:
				cancel();
		}
	}

	public abstract void yes();
	public abstract void no();
	public abstract void cancel();

}
