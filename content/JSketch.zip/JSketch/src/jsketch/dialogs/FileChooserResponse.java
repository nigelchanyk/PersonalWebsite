/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.dialogs;

import java.io.File;

/**
 *
 * @author Nigel
 */
public class FileChooserResponse extends AbstractDialogResponse {
	
	private File file;
	private int option;
	
	public FileChooserResponse(AbstractDialogRequest request, int option, File file) {
		super(request);
		this.file = file;
		this.option = option;
	}

	public File getFile() {
		return file;
	}

	public int getOption() {
		return option;
	}
	
}
