/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.dialogs;

/**
 *
 * @author Nigel
 */
public class CanvasConfigurationRequest extends AbstractDialogRequest {
	
	private int defaultWidth;
	private int defaultHeight;
	
	public CanvasConfigurationRequest(String title, Kind kind, int defaultWidth, int defaultHeight) {
		super(title, kind);
		this.defaultWidth = defaultWidth;
		this.defaultHeight = defaultHeight;
	}

	public int getDefaultHeight() {
		return defaultHeight;
	}

	public int getDefaultWidth() {
		return defaultWidth;
	}
	
}
