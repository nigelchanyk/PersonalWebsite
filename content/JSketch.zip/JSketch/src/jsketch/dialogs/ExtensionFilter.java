/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.dialogs;

import java.io.File;
import javax.swing.filechooser.FileFilter;

/**
 *
 * @author Nigel
 */
public class ExtensionFilter extends FileFilter {
	
	private String extension;
	private String description;

	public ExtensionFilter(String extension, String description) {
		this.extension = extension;
		this.description = description;
	}

	@Override
	public boolean accept(File pathname) {
		if (pathname.isDirectory())
			return true;

		return getExtension(pathname).equalsIgnoreCase(extension);
	}

	private String getExtension(File pathname) {
		String name = pathname.getName();
		int index = name.lastIndexOf('.');
		return index > 0 ? name.substring(index + 1) : name;
	}

	@Override
	public String getDescription() {
		return description;
	}
}
