/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.dialogs;


/**
 *
 * @author Nigel
 */
public class ConfirmDialogRequest extends AbstractDialogRequest {
	
	private String text;

	public ConfirmDialogRequest(String title, String text, Kind kind) {
		super(title, kind);
		this.text = text;
	}

	public String getText() {
		return text;
	}
}
