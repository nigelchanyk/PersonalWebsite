/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.dialogs;

/**
 *
 * @author Nigel
 */
public abstract class AbstractDialogRequest {
	
	public enum Kind {
		YES_NO,
		YES_NO_CANCEL,
		SAVE_DONT_CANCEL,
		OPEN_FILE,
		SAVE_FILE,
		CANVAS_CONFIGURATION
	}
	
	private String title;
	private Kind kind;

	public AbstractDialogRequest(String title, Kind kind) {
		this.title = title;
		this.kind = kind;
	}

	public Kind getKind() {
		return kind;
	}


	public String getTitle() {
		return title;
	}
	
}
