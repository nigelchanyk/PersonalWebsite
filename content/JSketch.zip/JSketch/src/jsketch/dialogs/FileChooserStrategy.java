/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.dialogs;

import java.io.File;
import javax.swing.JFileChooser;
import jsketch.exceptions.TypeMismatchException;

/**
 *
 * @author Nigel
 */
public abstract class FileChooserStrategy extends AbstractDialogStrategy {

	@Override
	public void execute(AbstractDialogResponse response) {
		if (!(response instanceof FileChooserResponse))
			throw new TypeMismatchException(response.getClass(), ConfirmDialogResponse.class);

		FileChooserResponse fileChooserResponse = (FileChooserResponse)response;
		switch (fileChooserResponse.getOption()) {
			case JFileChooser.APPROVE_OPTION:
				confirm(fileChooserResponse.getFile());
				break;
			case JFileChooser.CANCEL_OPTION:
				cancel();
				break;
		}
	}

	public abstract void confirm(File file);
	public abstract void cancel();
}
