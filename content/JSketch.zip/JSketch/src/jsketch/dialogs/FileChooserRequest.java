/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.dialogs;

/**
 *
 * @author Nigel
 */
public class FileChooserRequest extends AbstractDialogRequest {
	
	private String extension;
	private String description;

	public FileChooserRequest(String title, String extension, String description, Kind kind) {
		super(title, kind);
		this.extension = extension;
		this.description = description;
	}

	public String getExtension() {
		return extension;
	}

	public String getDescription() {
		return description;
	}
	
}
