/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.dialogs;

/**
 *
 * @author Nigel
 */
public class CanvasConfigurationResponse extends AbstractDialogResponse {
	
	private int option;
	private int width;
	private int height;

	public CanvasConfigurationResponse(AbstractDialogRequest request, int option, int width, int height) {
		super(request);

		this.option = option;
		this.width = width;
		this.height = height;
	}

	public int getHeight() {
		return height;
	}

	public int getOption() {
		return option;
	}

	public int getWidth() {
		return width;
	}
	
}
