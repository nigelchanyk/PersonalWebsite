/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.dialogs;

import javax.swing.JOptionPane;
import jsketch.exceptions.TypeMismatchException;

/**
 *
 * @author Nigel
 */
public abstract class CanvasConfigurationStrategy extends AbstractDialogStrategy {

	@Override
	public void execute(AbstractDialogResponse response) {
		if (!(response instanceof CanvasConfigurationResponse))
			throw new TypeMismatchException(response.getClass(), CanvasConfigurationResponse.class);

		CanvasConfigurationResponse ccr = (CanvasConfigurationResponse)response;
		if (ccr.getOption() == JOptionPane.OK_OPTION)
			confirm(ccr.getWidth(), ccr.getHeight());
		else
			cancel();
	}

	public abstract void confirm(int width, int height);
	public abstract void cancel();
	
}
