/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.dialogs;

import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import jsketch.ChangeEvent;
import jsketch.IView;
import jsketch.containers.CanvasConfigurationDialog;
import jsketch.containers.JSketchFrame;
import jsketch.exceptions.TypeMismatchException;
import jsketch.models.JSketchModel;

/**
 *
 * @author Nigel
 */
public class DialogViewController implements IView {

	private JSketchModel model;
	private JSketchFrame parent;
	
	public DialogViewController(JSketchModel model, JSketchFrame parent) {
		this.model = model;
		this.parent = parent;
		model.subscribe(this);
	}
	
	@Override
	public void update(ChangeEvent event) {
		if (event != ChangeEvent.NEW_DIALOG)
			return;

		AbstractDialogRequest request = model.getDialogRequest();
		if (request == null)
			return;

		switch (request.getKind()) {
			case YES_NO:
				sendYesNoDialog(request);
				break;
			case YES_NO_CANCEL:
				sendYesNoCancelDialog(request);
				break;
			case SAVE_DONT_CANCEL:
				sendSaveDontCancelDialog(request);
				break;
			case SAVE_FILE:
				sendSaveFileDialog(request);
				break;
			case OPEN_FILE:
				sendOpenFileDialog(request);
				break;
			case CANVAS_CONFIGURATION:
				sendCanvasConfigurationDialog(request);
				break;
		}
	}

	private void sendYesNoDialog(AbstractDialogRequest request) {
		if (!(request instanceof ConfirmDialogRequest))
			throw new TypeMismatchException(request.getClass(), ConfirmDialogRequest.class);

		int response = JOptionPane.showConfirmDialog(parent, ((ConfirmDialogRequest)request).getText(), request.getTitle(), JOptionPane.YES_NO_OPTION);
		model.dialogClosed(new ConfirmDialogResponse(request, response));
	}

	private void sendSaveDontCancelDialog(AbstractDialogRequest request) {
		if (!(request instanceof ConfirmDialogRequest))
			throw new TypeMismatchException(request.getClass(), ConfirmDialogRequest.class);
		String[] options = { "Save", "Don't Save", "Cancel" };
		
		int response = JOptionPane.showOptionDialog(parent, ((ConfirmDialogRequest)request).getText(), request.getTitle(), JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, "Cancel");
		model.dialogClosed(new ConfirmDialogResponse(request, response));
	}
	
	private void sendYesNoCancelDialog(AbstractDialogRequest request) {
		if (!(request instanceof ConfirmDialogRequest))
			throw new TypeMismatchException(request.getClass(), ConfirmDialogRequest.class);

		int response = JOptionPane.showConfirmDialog(parent, ((ConfirmDialogRequest)request).getText(), request.getTitle(), JOptionPane.YES_NO_CANCEL_OPTION);
		model.dialogClosed(new ConfirmDialogResponse(request, response));
	}

	private void sendCanvasConfigurationDialog(AbstractDialogRequest request) {
		if (!(request instanceof CanvasConfigurationRequest))
			throw new TypeMismatchException(request.getClass(), CanvasConfigurationRequest.class);

		CanvasConfigurationRequest ccr = (CanvasConfigurationRequest)request;
		CanvasConfigurationDialog dialog = CanvasConfigurationDialog.getDialog(parent, ccr.getTitle(), ccr.getDefaultWidth(), ccr.getDefaultHeight());
		model.dialogClosed(new CanvasConfigurationResponse(request, dialog.getOption(), dialog.getCanvasWidth(), dialog.getCanvasHeight()));
	}

	private void sendSaveFileDialog(AbstractDialogRequest request) {
		if (!(request instanceof FileChooserRequest))
			throw new TypeMismatchException(request.getClass(), FileChooserRequest.class);

		FileChooserRequest fcr = (FileChooserRequest)request;
		JFileChooser fileChooser = createFileChooser(fcr);
		int response = fileChooser.showSaveDialog(parent);
		
		File file = fileChooser.getSelectedFile();
		if (response == JFileChooser.APPROVE_OPTION) {
			if (!file.getAbsolutePath().endsWith("." + fcr.getExtension()))
				file = new File(file.getAbsolutePath() + "." + fcr.getExtension());
			if (file.exists()) {
				if (JOptionPane.showConfirmDialog(parent, file.getName() + " already exists. Would you like to overwrite the file?", request.getTitle(), JOptionPane.YES_NO_OPTION) == JOptionPane.NO_OPTION)
					response = JFileChooser.CANCEL_OPTION;
			}
		}
		
		model.dialogClosed(new FileChooserResponse(request, response, response == JFileChooser.APPROVE_OPTION ? file : null));
	}

	private void sendOpenFileDialog(AbstractDialogRequest request) {
		if (!(request instanceof FileChooserRequest))
			throw new TypeMismatchException(request.getClass(), FileChooserRequest.class);

		JFileChooser fileChooser = createFileChooser((FileChooserRequest)request);
		int response = fileChooser.showOpenDialog(parent);
		model.dialogClosed(new FileChooserResponse(request, response, response == JFileChooser.APPROVE_OPTION ? fileChooser.getSelectedFile() : null));
	}

	private JFileChooser createFileChooser(FileChooserRequest request) {
		ExtensionFilter filter = new ExtensionFilter(request.getExtension(), request.getDescription());
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle(request.getTitle());
		fileChooser.setFileFilter(filter);
		return fileChooser;
	}
}
