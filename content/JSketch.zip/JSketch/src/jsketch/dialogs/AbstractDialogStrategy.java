/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.dialogs;

/**
 *
 * @author Nigel
 */
public abstract class AbstractDialogStrategy {
	public abstract void execute(AbstractDialogResponse response);
}
