/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch;

import javax.swing.ToolTipManager;
import jsketch.containers.JSketchFrame;
import jsketch.models.JSketchModel;

/**
 *
 * @author Nigel
 */
public class Main {

	public static final int FRAMERATE = 30;
	public static final int FRAME_INTERVAL = 1000 / FRAMERATE;
	
	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		ToolTipManager.sharedInstance().setInitialDelay(300);
		
		JSketchModel model = new JSketchModel();
		JSketchFrame viewController = new JSketchFrame(model);
		viewController.setVisible(true);
		model.start();
	}
}
