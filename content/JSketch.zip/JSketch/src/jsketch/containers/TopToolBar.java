/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.containers;

import java.awt.Dimension;
import javax.swing.ButtonGroup;
import javax.swing.JToolBar;
import jsketch.components.buttons.*;
import jsketch.models.JSketchModel;

/**
 *
 * @author Nigel
 */
public class TopToolBar extends JToolBar {
	
	public TopToolBar(JSketchFrame frame, JSketchModel model) {
		super(HORIZONTAL);
		setFloatable(false);
		
		add(new NewButton(model));
		add(new OpenButton(model));
		add(new SaveButton(model));
		add(new SaveAsButton(model));
		add(new ExportButton(model));
		
		addSeparator(new Dimension(30, 10));
		
		add(new UndoButton(model));
		add(new RedoButton(model));

		addSeparator(new Dimension(30, 10));

		ButtonGroup group = new ButtonGroup();
		DrawButton drawButton = new DrawButton(model);
		EraseButton eraseButton = new EraseButton(model);
		TranslateButton translateButton = new TranslateButton(model);
		RotateButton rotateButton = new RotateButton(model);
		ScaleButton scaleButton = new ScaleButton(model);
		
		group.add(drawButton);
		group.add(eraseButton);
		group.add(translateButton);
		group.add(rotateButton);
		group.add(scaleButton);
		
		add(drawButton);
		add(eraseButton);
		add(translateButton);
		add(rotateButton);
		add(scaleButton);

		addSeparator(new Dimension(30, 10));

		add(new AboutButton(frame, model));
	}

	
	
}
