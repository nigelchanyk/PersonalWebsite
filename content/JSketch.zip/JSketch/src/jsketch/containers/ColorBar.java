/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.containers;

import java.awt.*;
import javax.swing.JColorChooser;
import javax.swing.JPanel;
import jsketch.components.ColorDisplay;
import jsketch.components.buttons.ColorButton;
import jsketch.models.JSketchModel;

/**
 *
 * @author Nigel
 */
public class ColorBar extends JPanel {

	private Color[] DEFAULT_COLORS = {Color.BLACK, Color.DARK_GRAY, Color.GRAY, Color.LIGHT_GRAY, Color.BLUE, Color.CYAN, Color.GREEN, Color.MAGENTA, Color.ORANGE, Color.PINK, Color.RED, Color.YELLOW};
	
	public ColorBar(JSketchFrame parent, JSketchModel model) {
		JPanel panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(1, 1, 1, 1);
		
		c.gridwidth = 2;
		c.gridheight = 2;
		c.gridx = 0;
		c.gridy = 0;
		panel.add(new ColorDisplay(model), c);

		c.gridwidth = 1;
		c.gridheight = 1;

		JColorChooser colorChooser = new JColorChooser(Color.WHITE);
		for (int row = 2, index = 0; row < 14; ++row) {
			for (int col = 0; col < 2; ++col, ++index) {
				c.gridx = col;
				c.gridy = row;
				panel.add(new ColorButton(parent, model, index < DEFAULT_COLORS.length ? DEFAULT_COLORS[index] : Color.WHITE, colorChooser), c);
			}
		}

		setLayout(new BorderLayout());
		add(panel, BorderLayout.NORTH);
	}
	
}
