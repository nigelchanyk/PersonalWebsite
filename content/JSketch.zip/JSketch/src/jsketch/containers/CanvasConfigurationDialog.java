/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.containers;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridLayout;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author Nigel
 */
public class CanvasConfigurationDialog extends JPanel {
	
	private JSpinner widthSpinner;
	private JSpinner heightSpinner;
	private int option;
	
	private CanvasConfigurationDialog(int width, int height) {
		setLayout(new BorderLayout());
		
		SpinnerModel widthModel = new SpinnerNumberModel(width, 1, 4096, 100);
		widthSpinner = new JSpinner(widthModel);
		SpinnerModel heightModel = new SpinnerNumberModel(height, 1, 4096, 100);
		heightSpinner = new JSpinner(heightModel);
		
		JPanel labelPanel = new JPanel(new GridLayout(2, 1));
		JLabel widthLabel = new JLabel("Width");
		widthLabel.setBorder(new EmptyBorder(0, 0, 0, 10));
		JLabel heightLabel = new JLabel("Height");
		heightLabel.setBorder(new EmptyBorder(0, 0, 0, 10));
		labelPanel.add(widthLabel);
		labelPanel.add(heightLabel);
		
		JPanel inputPanel = new JPanel(new GridLayout(2, 1));
		inputPanel.add(widthSpinner);
		inputPanel.add(heightSpinner);

		add(labelPanel, BorderLayout.WEST);
		add(inputPanel, BorderLayout.CENTER);
	}

	public int getOption() {
		return option;
	}

	public int getCanvasWidth() {
		return (int)widthSpinner.getValue();
	}

	public int getCanvasHeight() {
		return (int)heightSpinner.getValue();
	}
	
	public static CanvasConfigurationDialog getDialog(Component parent, String title, int width, int height) {
		CanvasConfigurationDialog panel = new CanvasConfigurationDialog(width, height);
		panel.option = JOptionPane.showConfirmDialog(parent, panel, title, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
		return panel;
	}	
	
}
