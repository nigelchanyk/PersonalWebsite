/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.containers;

import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import jsketch.dialogs.DialogViewController;
import jsketch.models.JSketchModel;

/**
 *
 * @author Nigel
 */
public class JSketchFrame extends JFrame {
	
	private JSketchModel model;
	private DialogViewController dialog;
	
	public JSketchFrame(JSketchModel model) {
		super("JSketch - A Simple Animation Creator");
		this.model = model;
		setSize(800, 600);
		setWindowCloseOperation();
		initializeComponents(model);
		dialog = new DialogViewController(model, this);
	}

	private void setWindowCloseOperation() {
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				model.closeApplication();
			}
		});
	}

	private void initializeComponents(JSketchModel model) {
		setLayout(new BorderLayout());
		add(new TopToolBar(this, model), BorderLayout.NORTH);
		add(new TimeframeController(this, model), BorderLayout.SOUTH);
		add(new CanvasContainer(model), BorderLayout.CENTER);
		add(new ColorBar(this, model), BorderLayout.EAST);
	}

}
