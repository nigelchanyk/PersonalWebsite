/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.containers;

import javax.swing.JScrollPane;
import jsketch.components.DrawableCanvas;
import jsketch.models.JSketchModel;

/**
 *
 * @author Nigel
 */
public class CanvasContainer extends JScrollPane {
	
	public CanvasContainer(JSketchModel model) {
		DrawableCanvas canvas = new DrawableCanvas(model);
		setViewportView(canvas);
	}
	
}
