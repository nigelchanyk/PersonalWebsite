/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.containers;

import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JPanel;
import jsketch.components.TimeSlider;
import jsketch.components.buttons.*;
import jsketch.models.JSketchModel;

/**
 *
 * @author Nigel
 */
public class TimeframeController extends JPanel {
	
	private JSketchModel model;
	private JPanel topPanel;
	private JPanel bottomPanel;
	
	public TimeframeController(JSketchFrame frame, JSketchModel model) {
		this.model = model;
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		
		topPanel = new JPanel();
		add(topPanel);
		topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.X_AXIS));
		topPanel.add(Box.createRigidArea(new Dimension(10, 0)));
		topPanel.add(new TimeSlider(frame, model));
		topPanel.add(Box.createRigidArea(new Dimension(10, 0)));
		
		bottomPanel = new JPanel();
		add(bottomPanel);
		bottomPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
		bottomPanel.add(new SkipToStartButton(model));
		bottomPanel.add(new PreviousFrameButton(model));
		bottomPanel.add(new PlayButton(model));
		bottomPanel.add(new NextFrameButton(model));
		bottomPanel.add(new SkipToEndButton(model));
	}
	
}
