/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.utilities;

import java.io.*;
import jsketch.project.JSketchProject;

/**
 *
 * @author Nigel
 */
public class ProjectSerializer {

	public static JSketchProject load(File file) throws IOException, ClassNotFoundException {
		JSketchProject project;
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
			project = (JSketchProject)in.readObject();
		}
		return project;
	}
	
	public static void save(JSketchProject project, File file) throws IOException {
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))) {
			out.writeObject(project);
		}
	}

}
