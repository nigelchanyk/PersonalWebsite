/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.utilities;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.io.*;
import jsketch.json.JSONObject;
import jsketch.json.JSONString;
import jsketch.project.JSketchProject;

/**
 *
 * @author Nigel
 */
public class ProjectExporter {
	
	private static final String PROJECT_MARKER = "##PROJECT##";
	
	public static void exportHtml(JSketchProject project, File file) throws IOException {
		StringBuilder builder = new StringBuilder();
		try (BufferedReader reader = new BufferedReader(new FileReader("template"))) {
			while (reader.ready())
				builder.append(reader.readLine()).append('\n');
		}
		
		StringBuilder json = new StringBuilder();
		project.toJSON().writeJson(json);
		int index = builder.indexOf(PROJECT_MARKER);
		if (index >= 0)
			builder.replace(index, index + PROJECT_MARKER.length(), json.toString());
		
		try (BufferedWriter out = new BufferedWriter(new FileWriter(file))) {
			out.write(builder.toString());
		}
	}

	public static void exportJson(JSketchProject project, File file) throws IOException {
		StringBuilder json = new StringBuilder();
		project.toJSON().writeJson(json);
		try (BufferedWriter out = new BufferedWriter(new FileWriter(file))) {
			out.write(json.toString());
		}
	}
	
	public static JSONObject serializePoint(Point point) {
		JSONObject obj = new JSONObject();
		obj.put("x", point.x);
		obj.put("y", point.y);
		return obj;
	}

	public static JSONObject serializeTransform(AffineTransform transform) {
		double[] matrix = new double[6];
		transform.getMatrix(matrix);

		JSONObject obj = new JSONObject();
		obj.put("m00", matrix[0]);
		obj.put("m10", matrix[1]);
		obj.put("m01", matrix[2]);
		obj.put("m11", matrix[3]);
		obj.put("m02", matrix[4]);
		obj.put("m12", matrix[5]);

		return obj;
	}
	
	public static JSONObject serializeDimension(Dimension dimension) {
		JSONObject obj = new JSONObject();
		obj.put("width", dimension.width);
		obj.put("height", dimension.height);
		return obj;
	}

	public static JSONString serializeColor(Color color) {
		String hex = Integer.toHexString(color.getRGB() & 0xFFFFFF);
		return new JSONString("#000000".substring(0, 7 - hex.length()) + hex);
	}
}
