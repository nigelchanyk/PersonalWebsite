/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.utilities;

import jsketch.Main;

/**
 *
 * @author Nigel
 */
public class MathHelper {
	
	public static String toTime(int frame) {
		return String.format("%02d:%02d:%03d", frame / (60 * Main.FRAMERATE), frame / Main.FRAMERATE % 60, frame % Main.FRAMERATE * Main.FRAME_INTERVAL);
	}
	
}
