/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.utilities;

import java.io.File;
import java.util.HashMap;
import javax.swing.ImageIcon;
import jsketch.exceptions.IconNotFoundException;

/**
 *
 * @author Nigel
 */
public class IconImporter {

	private static HashMap<String, ImageIcon> iconCache = new HashMap<>();
	
	public static ImageIcon load(String name) {
		if (iconCache.containsKey(name))
			return iconCache.get(name);
		
		File file = new File("icons/" + name);
		if (!file.exists())
			throw new IconNotFoundException(file.getPath());

		ImageIcon icon = new ImageIcon(file.getPath());
		iconCache.put(name, icon);
		return icon;
	}
}
