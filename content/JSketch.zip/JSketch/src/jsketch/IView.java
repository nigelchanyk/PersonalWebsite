/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch;

/**
 *
 * @author Nigel
 */
public interface IView {
	public void update(ChangeEvent event);
}
