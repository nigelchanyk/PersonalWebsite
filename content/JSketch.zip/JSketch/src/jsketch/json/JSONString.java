/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.json;

/**
 *
 * @author Nigel
 */
public class JSONString extends JSONType {

	private String value;

	public JSONString(String value) {
		this.value = escape(value);
	}
	
	@Override
	public void writeJson(StringBuilder out) {
		out.append("\"").append(value).append("\"");
	}

}
