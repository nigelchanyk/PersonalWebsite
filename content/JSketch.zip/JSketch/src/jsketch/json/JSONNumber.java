/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.json;

/**
 *
 * @author Nigel
 */
public class JSONNumber extends JSONType {

	private double value;
	
	public JSONNumber(double value) {
		this.value = value;
	}
	
	@Override
	public void writeJson(StringBuilder out) {
		out.append(value);
	}
	
}
