/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.json;

import java.util.LinkedList;

/**
 *
 * @author Nigel
 */
public class JSONObject extends JSONType {

	private LinkedList<KeyValuePair> collection = new LinkedList<>();

	public void put(String key, JSONType value) {
		collection.addLast(new KeyValuePair(key, value));
	}

	public void put(String key, JSONSerializable value) {
		put(key, value.toJSON());
	}

	public void put(String key, int value) {
		put(key, new JSONInteger(value));
	}

	public void put(String key, double value) {
		put(key, new JSONNumber(value));
	}

	public void put(String key, Iterable<JSONSerializable> values) {
		JSONArray array = new JSONArray();
		for (JSONSerializable value : values)
			array.add(value.toJSON());
		put(key, array);
	}
	
	@Override
	public void writeJson(StringBuilder out) {
		out.append("{ ");

		int count = collection.size();
		int index = 0;
		for (KeyValuePair pair : collection) {
			out.append('\"').append(escape(pair.key)).append("\": ");
			pair.value.writeJson(out);

			if (index < count - 1)
				out.append(", ");
			index++;
		}

		out.append(" }");
	}

	private class KeyValuePair {
		public String key;
		public JSONType value;

		public KeyValuePair(String key, JSONType value) {
			this.key = key;
			this.value = value;
		}
	}
	
}
