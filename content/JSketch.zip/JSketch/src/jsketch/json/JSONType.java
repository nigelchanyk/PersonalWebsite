/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.json;

/**
 *
 * @author Nigel
 */
public abstract class JSONType {
	public abstract void writeJson(StringBuilder out);

	protected static String escape(String line) {
		return line.replaceAll("\"", "\\\"");
	}
}
