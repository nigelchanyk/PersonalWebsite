/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.json;

/**
 *
 * @author Nigel
 */
public class JSONInteger extends JSONType {

	private int value;
	
	public JSONInteger(int value) {
		this.value = value;
	}
	
	@Override
	public void writeJson(StringBuilder out) {
		out.append(value);
	}
	
}
