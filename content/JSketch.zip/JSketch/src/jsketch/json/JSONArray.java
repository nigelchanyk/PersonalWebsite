/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.json;

import java.util.LinkedList;

/**
 *
 * @author Nigel
 */
public class JSONArray extends JSONType {

	private LinkedList<JSONType> collection = new LinkedList<>();

	public void add(JSONType element) {
		collection.addLast(element);
	}
	
	@Override
	public void writeJson(StringBuilder out) {
		out.append("[ ");

		int count = collection.size();
		int index = 0;
		for (JSONType element : collection) {
			element.writeJson(out);

			if (index < count - 1)
				out.append(", ");
			index++;
		}

		out.append(" ]");
	}
	
}
