/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import javax.swing.JComponent;
import javax.swing.SwingUtilities;
import jsketch.ChangeEvent;
import jsketch.IView;
import jsketch.models.CanvasModel;
import jsketch.models.JSketchModel;
import jsketch.models.TimerModel;
import jsketch.project.JSketchSelection;
import jsketch.project.JSketchStroke;

/**
 *
 * @author Nigel
 */
public class DrawableCanvas extends JComponent implements IView {
	
	public static final BasicStroke STANDARD_STROKE = new BasicStroke(3);
	private static final BasicStroke SELECTED_STROKE = new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[] {3}, 0);
	private static final BasicStroke SELECTION_STROKE = new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[] {10}, 0);
	private static final BasicStroke RECORD_FRAME_STROKE = new BasicStroke(20);

	private static final Cursor DEFAULT_CURSOR = new Cursor(Cursor.DEFAULT_CURSOR);
	private static final Cursor MOVE_CURSOR = new Cursor(Cursor.MOVE_CURSOR);

	private static final Color RECORD_FRAME_COLOR = new Color(255, 0, 0, 128);
	
	private JSketchModel model;

	public DrawableCanvas(JSketchModel model) {
		this.model = model;
		setFocusable(true);
		setPreferredSize(model.getCanvasDimension());
		initializeListeners();
		model.subscribe(this);
	}

	private void initializeListeners() {
		addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				if (SwingUtilities.isLeftMouseButton(e))
					mouseDown(e, true);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				if (SwingUtilities.isLeftMouseButton(e)) {
					switch (model.getCanvasMode()) {
						case DRAW:
							model.drawPointEnd();
							break;
						case SELECT:
							model.drawSelectionEnd();
							break;
						case TRANSFORM:
							model.transformSelectionEnd();
							model.setCanvasMode(CanvasModel.Mode.SELECT);
							break;
					}
				}
				else if (SwingUtilities.isRightMouseButton(e)) {
					switch (model.getCanvasMode()) {
						case SELECT:
							model.setSelectionCenter(e.getPoint());
							break;
					}
				}
			}

		});

		addMouseMotionListener(new MouseMotionAdapter() {
		
			@Override
			public void mouseDragged(MouseEvent e) {
				if (SwingUtilities.isLeftMouseButton(e))
					mouseDown(e, false);
			}

			@Override
			public void mouseMoved(MouseEvent e) {
				if (model.getSelection().isSelected(e.getPoint(), model.getCurrentFrame()))
					setCursor(MOVE_CURSOR);
				else
					setCursor(DEFAULT_CURSOR);
			}
		});
	}

	private void mouseDown(MouseEvent e, boolean first) {
		switch (model.getCanvasMode()) {
			case DRAW:
				model.setTimerState(TimerModel.State.PAUSE);
				model.drawPoint(e.getPoint());
				break;
			case SELECT:
				if (model.getSelection().isSelected(e.getPoint(), model.getCurrentFrame())) {
					model.setCanvasMode(CanvasModel.Mode.TRANSFORM);
					model.transformSelection(e.getPoint(), first);
				}
				else {
					model.drawSelection(e.getPoint(), first);
					model.setTimerState(TimerModel.State.PAUSE);
				}
				break;
			case TRANSFORM:
				model.transformSelection(e.getPoint(), first);
				break;
			case ERASE:
				model.setTimerState(TimerModel.State.PAUSE);
				model.eraseStroke(e.getPoint());
				break;
		}
	}

	@Override
	protected void paintComponent(Graphics graphics) {
		// Determine clipping region
		Graphics2D g = (Graphics2D) graphics;
		
		Rectangle rect = g.getClipBounds();
		g.setColor(Color.GRAY);
		g.fillRect(rect.x, rect.y, rect.width, rect.height);
		g.setClip(rect.x, rect.y, Math.min(model.getCanvasDimension().width, rect.width), Math.min(model.getCanvasDimension().height, rect.height));
		
		// All drawings below are clipped if out of bound
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, model.getCanvasDimension().width, model.getCanvasDimension().height);

		JSketchSelection selection = model.getSelection();
		for (JSketchStroke stroke : model.getCurrentStrokes())
			paintStroke(g, stroke, selection);

		if (model.getIncompleteStroke() != null)
			paintStroke(g, model.getIncompleteStroke(), selection);
		if (selection.getPointsCount() > 0)
			paintSelection(g, selection);

		if (model.getTimerState() == TimerModel.State.RECORD) {
			g.setColor(RECORD_FRAME_COLOR);
			g.setStroke(RECORD_FRAME_STROKE);
			g.drawRect(10, 10, model.getCanvasDimension().width - 20, model.getCanvasDimension().height - 20);
		}
	}

	private void paintStroke(Graphics2D g, JSketchStroke stroke, JSketchSelection selection) {
		if (!stroke.isVisible(model.getCurrentFrame()))
			return;
		
		g.setStroke(STANDARD_STROKE);
		g.setColor(stroke.getColor());

		if (selection != null) {
			if (selection.isVisible(model.getCurrentFrame())) {
				if (selection.isSelected(stroke)) {
					g.setStroke(SELECTED_STROKE);
				}
			}
		}
		g.draw(stroke.toGeneralPath(model.getCurrentFrame()));
	}

	private void paintSelection(Graphics2D g, JSketchSelection selection) {
		if (!selection.isVisible(model.getCurrentFrame()))
			return;
		
		g.setStroke(SELECTION_STROKE);
		g.setColor(Color.ORANGE);
		g.draw(selection.toGeneralPath(model.getCurrentFrame()));

		Point center = selection.getCenter(model.getCurrentFrame());
		if (center != null) {
			g.setStroke(STANDARD_STROKE);
			g.drawOval(center.x - 5, center.y - 5, 10, 10);
		}
	}

	@Override
	public void update(ChangeEvent event) {
		if (event == ChangeEvent.PROJECT_CHANGED)
			setPreferredSize(model.getCanvasDimension());
		else if (event == ChangeEvent.CANVAS_UPDATE || event == ChangeEvent.TIMEFRAME_UPDATE)
			repaint();
	}
	
}
