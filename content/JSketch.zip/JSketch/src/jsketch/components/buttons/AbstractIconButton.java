/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components.buttons;

import javax.swing.JButton;
import jsketch.models.JSketchModel;
import jsketch.utilities.IconImporter;

/**
 *
 * @author Nigel
 */
public abstract class AbstractIconButton extends JButton {
	
	protected JSketchModel jsketchModel;

	public AbstractIconButton(JSketchModel model, String text, String iconName, String tooltip) {
		super(text, IconImporter.load(iconName));
		this.jsketchModel = model;
		setToolTipText(tooltip);
	}

	public AbstractIconButton(JSketchModel model, String iconName, String tooltip) {
		super(IconImporter.load(iconName));
		this.jsketchModel = model;
		setToolTipText(tooltip);
	}
	
}
