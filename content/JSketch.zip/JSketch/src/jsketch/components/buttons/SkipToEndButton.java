/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components.buttons;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import jsketch.ChangeEvent;
import jsketch.IView;
import jsketch.models.JSketchModel;
import jsketch.models.TimerModel;

/**
 *
 * @author Nigel
 */
public class SkipToEndButton extends AbstractIconButton implements IView {
	
	public SkipToEndButton(JSketchModel model) {
		super(model, "double-right.png", "Skip to End");
		setEnabled(false);
		addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				jsketchModel.setTimerState(TimerModel.State.PAUSE);
				jsketchModel.setCurrentFrame(jsketchModel.getLastMotionalFrame());
			}
		});
		
		model.subscribe(this);
	}

	@Override
	public void update(ChangeEvent event) {
		if (event != ChangeEvent.TIMEFRAME_UPDATE)
			return;

		setEnabled(jsketchModel.getTimerState() != TimerModel.State.RECORD && jsketchModel.getCurrentFrame() != jsketchModel.getLastMotionalFrame());
	}
	
}
