/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components.buttons;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import jsketch.containers.JSketchFrame;
import jsketch.models.JSketchModel;

/**
 *
 * @author Nigel
 */
public class AboutButton extends AbstractIconButton {
	
	private JSketchFrame parent;
	
	public AboutButton(JSketchFrame parentFrame, JSketchModel model) {
		super(model, "about.png", "About");
		this.parent = parentFrame;

		addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(parent, "Created by: Nigel Chan\n\nAll icons are provided by various open source projects listed below:\n\nOxygen\nhttp://www.oxygen-icons.org/\nDual license: CC-BY-SA 3.0 or LGPL\n\nCrystal Project\nhttp://www.everaldo.com/\nLGPL-2.1\n\nAll icons are available at http://openiconlibrary.sourceforge.net/", "About", JOptionPane.INFORMATION_MESSAGE);
			}
		});
	}
	
}
