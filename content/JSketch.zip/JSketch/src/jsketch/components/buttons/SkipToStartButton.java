/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components.buttons;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import jsketch.ChangeEvent;
import jsketch.IView;
import jsketch.models.JSketchModel;
import jsketch.models.TimerModel;

/**
 *
 * @author Nigel
 */
public class SkipToStartButton extends AbstractIconButton implements IView {
	
	public SkipToStartButton(JSketchModel model) {
		super(model, "double-left.png", "Skip to Start");
		setEnabled(false);
		addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				jsketchModel.setTimerState(TimerModel.State.PAUSE);
				jsketchModel.setCurrentFrame(0);
			}
		});
		model.subscribe(this);
	}

	@Override
	public void update(ChangeEvent event) {
		if (event != ChangeEvent.TIMEFRAME_UPDATE)
			return;

		setEnabled(jsketchModel.getCurrentFrame() > 0);
	}

	
	
}
