/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components.buttons;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import jsketch.ChangeEvent;
import jsketch.IView;
import jsketch.models.JSketchModel;
import jsketch.models.TimerModel;
import jsketch.utilities.IconImporter;
import jsketch.utilities.MathHelper;

/**
 *
 * @author Nigel
 */
public class PlayButton extends AbstractIconButton implements IView {
	
	private ImageIcon playIcon;
	private ImageIcon pauseIcon;
	private TimerModel.State lastState;
	
	public PlayButton(JSketchModel model) {
		super(model, MathHelper.toTime(model.getCurrentFrame()), "play.png", "Play");
		setEnabled(false);
		playIcon = IconImporter.load("play.png");
		pauseIcon = IconImporter.load("pause.png");
		lastState = model.getTimerState();

		addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (lastState == TimerModel.State.PAUSE) {
					if (jsketchModel.getCurrentFrame() >= jsketchModel.getLastMotionalFrame())
						jsketchModel.setCurrentFrame(0);

					jsketchModel.setTimerState(TimerModel.State.PLAY);
				}
				else
					jsketchModel.setTimerState(TimerModel.State.PAUSE);
			}
		});
		model.subscribe(this);
	}

	@Override
	public void update(ChangeEvent event) {
		if (event != ChangeEvent.TIMEFRAME_UPDATE && event != ChangeEvent.PROJECT_CHANGED && event != ChangeEvent.HISTORY_UPDATE && event != ChangeEvent.CANVAS_UPDATE)
			return;

		setEnabled(jsketchModel.getLastMotionalFrame() > 0);

		if (jsketchModel.getExtendFrameStart() >= 0) {
			int difference = jsketchModel.getCurrentFrame() - jsketchModel.getExtendFrameStart();
			setForeground(difference < 0 ? Color.RED : Color.BLUE);
			setText(MathHelper.toTime(jsketchModel.getCurrentFrame()) + " (" + MathHelper.toTime(jsketchModel.getExtendFrameStart()) + " + " + MathHelper.toTime(Math.max(0, difference)) + ")");
		}
		else {
			setForeground(Color.BLACK);
			setText(MathHelper.toTime(jsketchModel.getCurrentFrame()));
		}

		if (lastState != jsketchModel.getTimerState()) {
			lastState = jsketchModel.getTimerState();
			if (lastState == TimerModel.State.PAUSE) {
				setIcon(playIcon);
				setToolTipText("Play");
			}
			else {
				setIcon(pauseIcon);
				setToolTipText("Pause");
			}
		}
	}
	
}
