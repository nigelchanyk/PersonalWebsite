/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components.buttons;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import jsketch.ChangeEvent;
import jsketch.IView;
import jsketch.models.CanvasModel;
import jsketch.models.JSketchModel;

/**
 *
 * @author Nigel
 */
public class RotateButton extends AbstractIconToggleButton implements IView {
	
	public RotateButton(JSketchModel model) {
		super(model, "rotate.png", "Select and Rotate");
		addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (isSelected()) {
					jsketchModel.setCanvasMode(CanvasModel.Mode.SELECT);
					jsketchModel.setTransformType(CanvasModel.TransformType.ROTATE);
				}
			}
		});

		model.subscribe(this);
	}
	
	@Override
	public void update(ChangeEvent event) {
		if (event == ChangeEvent.PROJECT_CHANGED)
			setSelected(jsketchModel.getCanvasMode() == CanvasModel.Mode.SELECT && jsketchModel.getTransformType() == CanvasModel.TransformType.ROTATE);
	}
}
