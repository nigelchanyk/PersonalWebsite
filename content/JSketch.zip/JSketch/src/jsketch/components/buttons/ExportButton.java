/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components.buttons;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import jsketch.models.JSketchModel;
import jsketch.models.ProjectModel;

/**
 *
 * @author Nigel
 */
public class ExportButton extends AbstractIconButton {
	
	public ExportButton(JSketchModel model) {
		super(model, "export.png", "Export As HTML 5 Animation");

		addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				jsketchModel.exportProject(ProjectModel.ExportType.HTML);
			}
		});
	}
	
}
