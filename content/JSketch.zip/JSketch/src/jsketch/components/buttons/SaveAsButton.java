/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components.buttons;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import jsketch.models.JSketchModel;

/**
 *
 * @author Nigel
 */
public class SaveAsButton extends AbstractIconButton {
	
	public SaveAsButton(JSketchModel model) {
		super(model, "save-as.png", "Save Project As");
		addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				jsketchModel.saveProject(true);
			}
		});
	}
	
}
