/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components.buttons;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import jsketch.ChangeEvent;
import jsketch.IView;
import jsketch.models.JSketchModel;
import jsketch.models.TimerModel;

/**
 *
 * @author Nigel
 */
public class NextFrameButton extends AbstractIconButton implements IView {
	
	public NextFrameButton(JSketchModel model) {
		super(model, "right.png", "Next Frame");
		addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				jsketchModel.setTimerState(TimerModel.State.PAUSE);
				jsketchModel.setCurrentFrame(jsketchModel.getCurrentFrame() + 1);
			}
		});

		model.subscribe(this);
	}

	@Override
	public void update(ChangeEvent event) {
		if (event != ChangeEvent.TIMEFRAME_UPDATE)
			return;

		setEnabled(jsketchModel.getCurrentFrame() < Integer.MAX_VALUE);
	}
	
}
