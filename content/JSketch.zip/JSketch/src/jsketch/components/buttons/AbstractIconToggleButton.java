/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components.buttons;

import javax.swing.JToggleButton;
import jsketch.models.JSketchModel;
import jsketch.utilities.IconImporter;

/**
 *
 * @author Nigel
 */
public abstract class AbstractIconToggleButton extends JToggleButton {
	
	protected JSketchModel jsketchModel;

	public AbstractIconToggleButton(JSketchModel model, String text, String iconName, String tooltip) {
		super(text, IconImporter.load(iconName));
		this.jsketchModel = model;
		setToolTipText(tooltip);
	}

	public AbstractIconToggleButton(JSketchModel model, String iconName, String tooltip) {
		super(IconImporter.load(iconName));
		this.jsketchModel = model;
		setToolTipText(tooltip);
	}
	
}
