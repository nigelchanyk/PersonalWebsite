/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components.buttons;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JDialog;
import javax.swing.SwingUtilities;
import jsketch.containers.JSketchFrame;
import jsketch.models.JSketchModel;

/**
 *
 * @author Nigel
 */
public class ColorButton extends JButton {
	
	JSketchFrame parentFrame;
	JSketchModel jsketchModel;
	JColorChooser colorChooser;
	Color color;
	
	public ColorButton(JSketchFrame parent, JSketchModel model, Color initialColor, JColorChooser sharedColorChooser) {
		this.jsketchModel = model;
		this.parentFrame = parent;
		this.colorChooser = sharedColorChooser;
		this.color = initialColor;

		setBackground(color);
		setPreferredSize(new Dimension(24, 24));
		addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				jsketchModel.setCurrentColor(color);
			}
		});

		addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if (SwingUtilities.isRightMouseButton(e))
					getModel().setPressed(true);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				if (SwingUtilities.isRightMouseButton(e)) {
					getModel().setPressed(false);
					JDialog dialog = JColorChooser.createDialog(parentFrame, "Set Color", true, colorChooser, new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							color = colorChooser.getColor();
							setBackground(new Color(color.getRGB(), false));
							jsketchModel.setCurrentColor(colorChooser.getColor());
						}
					}, new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
						}
					});
					dialog.setVisible(true);
				}
			}
		});
	}
	
}
