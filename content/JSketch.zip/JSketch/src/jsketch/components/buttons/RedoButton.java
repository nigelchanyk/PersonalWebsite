/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components.buttons;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import jsketch.ChangeEvent;
import jsketch.IView;
import jsketch.models.JSketchModel;

/**
 *
 * @author Nigel
 */
public class RedoButton extends AbstractIconButton implements IView {
	
	public RedoButton(JSketchModel model) {
		super(model, "redo.png", "Redo");
		setEnabled(false);
		model.subscribe(this);
		addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				jsketchModel.redo();
			}
		});
	}

	@Override
	public void update(ChangeEvent event) {
		if (event != ChangeEvent.HISTORY_UPDATE)
			return;

		setEnabled(jsketchModel.hasRedoEvents());
		if (isEnabled())
			setToolTipText("Redo " + jsketchModel.getNextRedoDescription());
		else
			setToolTipText(null);
	}
	
}
