/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components.buttons;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import jsketch.ChangeEvent;
import jsketch.IView;
import jsketch.models.JSketchModel;

/**
 *
 * @author Nigel
 */
public class UndoButton extends AbstractIconButton implements IView {
	
	public UndoButton(JSketchModel model) {
		super(model, "undo.png", "Undo");
		setEnabled(false);
		model.subscribe(this);
		addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				jsketchModel.undo();
			}
		});
	}

	@Override
	public void update(ChangeEvent event) {
		if (event != ChangeEvent.HISTORY_UPDATE)
			return;

		setEnabled(jsketchModel.hasUndoEvents());
		if (isEnabled())
			setToolTipText("Undo " + jsketchModel.getNextUndoDescription());
		else
			setToolTipText(null);
	}
	
}
