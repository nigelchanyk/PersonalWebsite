/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components;

import java.awt.Point;
import java.awt.event.*;
import java.util.Hashtable;
import javax.swing.*;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.metal.MetalSliderUI;
import jsketch.ChangeEvent;
import jsketch.IView;
import jsketch.Main;
import jsketch.containers.JSketchFrame;
import jsketch.models.JSketchModel;
import jsketch.models.TimerModel;
import jsketch.utilities.MathHelper;

/**
 *
 * @author Nigel
 */
public class TimeSlider extends JSlider implements IView {
	
	private static final int MINIMUM_FRAME_DISPLAYED = Main.FRAMERATE * 10;
	
	private JSketchFrame parent;
	private JSketchModel model;
	private TimeSliderPreview preview;
	private Popup popup;
	private MetalSliderUI sliderUI;
	private int totalLabels = 0;
	private boolean autoAdjustment = false;
	private boolean insertTime = false;
	private TimeSlider _this;
	private Point previewPosition;
	
	public TimeSlider(JSketchFrame parent, JSketchModel model) {
		this.parent = parent;
		this.model = model;
		this.setMinimum(0);
		this.setMaximum(MINIMUM_FRAME_DISPLAYED);
		adjustMaximum();
		this.setValue(model.getCurrentFrame());
		_this = this;
		preview = new TimeSliderPreview(model);
		preview.setComponent(this);
		setPaintTicks(true);
		setPaintLabels(true);
		setVisible(true);
		model.subscribe(this);
		addEvents();

		sliderUI = new MetalSliderUI() {
			
			@Override
			protected void scrollDueToClickInTrack(int direction) {
				_this.setValue(valueForXPosition(_this.getMousePosition().x));
			}
		};
		setUI(sliderUI);
	}

	private void addEvents() {
		addComponentListener(new ComponentAdapter() {

			@Override
			public void componentResized(ComponentEvent e) {
				setLabels(false);
			}
		});

		addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(javax.swing.event.ChangeEvent e) {
				if (autoAdjustment)
					return;

				model.setTimerState(TimerModel.State.PAUSE);
				model.setCurrentFrame(getValue());
				if (insertTime)
					model.extendFrame();
			}
		});

		addKeyListener(new KeyAdapter() {

			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_CONTROL)
					insertTime = true;
			}

			@Override
			public void keyReleased(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_CONTROL) {
					insertTime = false;
					model.extendFrameEnd();
				}
			}
		});

		addMouseListener(new MouseAdapter() {

			@Override
			public void mouseExited(MouseEvent e) {
				if (popup != null)
					popup.hide();
			}
		});

		addMouseMotionListener(new MouseMotionAdapter() {
		
			@Override
			public void mouseDragged(MouseEvent e) {
				refreshPreview(e);
			}

			@Override
			public void mouseMoved(MouseEvent e) {
				refreshPreview(e);
			}
		});
	}

	private void refreshPreview(MouseEvent e) {
		if (popup != null)
			popup.hide();
		previewPosition = TimeSliderPreview.createOffset(e.getLocationOnScreen(), getLocationOnScreen());
		if (previewPosition.x < parent.getContentPane().getLocationOnScreen().x) {
			preview.setArrowOffset(previewPosition.x - parent.getContentPane().getLocationOnScreen().x);
			previewPosition.x = parent.getContentPane().getLocationOnScreen().x;
		}
		else if (previewPosition.x + TimeSliderPreview.DIMENSION.width > parent.getContentPane().getLocationOnScreen().x + parent.getContentPane().getWidth()) {
			preview.setArrowOffset(previewPosition.x - parent.getContentPane().getLocationOnScreen().x - parent.getContentPane().getWidth() + TimeSliderPreview.DIMENSION.width);
			previewPosition.x = parent.getContentPane().getLocationOnScreen().x + parent.getContentPane().getWidth() - TimeSliderPreview.DIMENSION.width;
		}
		else
			preview.setArrowOffset(0);
		
		popup = PopupFactory.getSharedInstance().getPopup(this, preview, previewPosition.x, previewPosition.y);
		popup.show();

		preview.setDisplayTimeFrame(sliderUI.valueForXPosition(e.getX()));
		preview.repaint();
	}

	private void setLabels(boolean rangeUpdate) {
		int curTotalLabels = getSize().width / 70 - 1;	
		if (curTotalLabels == totalLabels && !rangeUpdate)
			return;
		totalLabels = curTotalLabels;

		Hashtable<Integer, JLabel> labelTable = new Hashtable<>();
		
		for (int i = 0; i <= curTotalLabels; ++i) {
			int frame = getMaximum() * i / curTotalLabels;
			labelTable.put(new Integer(frame), new JLabel(MathHelper.toTime(frame)));
		}

		setLabelTable(labelTable);
		setMajorTickSpacing(getMaximum() / curTotalLabels);
	}

	@Override
	public void update(ChangeEvent event) {
		if (event == ChangeEvent.INITIALIZED)
			setLabels(true);
		else if (event == ChangeEvent.TIMEFRAME_UPDATE) {
			autoAdjustment = true;
			// Do not adjust maximum when user is extending frame
			if (model.getExtendFrameStart() == -1)
				adjustMaximum();
			setValue(model.getCurrentFrame());
			autoAdjustment = false;
		}
	}

	private void adjustMaximum() {
		int previousMax = getMaximum();

		if (model.getCurrentFrame() > getMaximum())
			setMaximum(getMaximum() + MINIMUM_FRAME_DISPLAYED);
		else if (model.getCurrentFrame() <= model.getLastMotionalFrame())
			setMaximum(model.getLastMotionalFrame() / (Main.FRAMERATE * 5) * (Main.FRAMERATE * 5) + MINIMUM_FRAME_DISPLAYED);

		if (previousMax != getMaximum())
			setLabels(true);
	}

	@Override
	public JToolTip createToolTip() {
		return preview;
	}
	
}
