/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components;

import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JComponent;
import jsketch.ChangeEvent;
import jsketch.IView;
import jsketch.models.JSketchModel;

/**
 *
 * @author Nigel
 */
public class ColorDisplay extends JComponent implements IView {
	
	private JSketchModel model;
	
	public ColorDisplay(JSketchModel model) {
		this.model = model;
		setPreferredSize(new Dimension(48, 48));
		model.subscribe(this);
	}

	@Override
	public void paintComponent(Graphics g) {
		g.setColor(model.getCurrentColor());
		g.fillRect(0, 0, 48, 48);
	}

	@Override
	public void update(ChangeEvent event) {
		if (event == ChangeEvent.COLOR_UPDATE)
			setBackground(model.getCurrentColor());
	}
	
}
