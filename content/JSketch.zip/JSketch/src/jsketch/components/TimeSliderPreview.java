/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.components;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import javax.swing.JComponent;
import javax.swing.JToolTip;
import javax.swing.plaf.metal.MetalToolTipUI;
import jsketch.models.JSketchModel;
import jsketch.project.JSketchStroke;

/**
 *
 * @author Nigel
 */
public class TimeSliderPreview extends JToolTip {

	public static final Dimension DIMENSION = new Dimension(120, 130);
	
	private static final int BUBBLE_CENTER_X = 60;
	private static final int[] ARROW_Y = {120, 130, 120};

	private TimeSliderPreviewUI previewUI;

	public static Point createOffset(Point cursorLocation, Point componentLocation) {
		return new Point(cursorLocation.x - 60, componentLocation.y - 145);
	}
	
	public TimeSliderPreview(JSketchModel model) {
		super();
		previewUI = new TimeSliderPreviewUI(model);
		setUI(previewUI);
		setOpaque(false);
	}

	public void setDisplayTimeFrame(int timeFrame) {
		previewUI.displayTimeFrame = timeFrame;
	}

	public void setArrowOffset(int arrowOffset) {
		previewUI.arrowX[1] = BUBBLE_CENTER_X + arrowOffset;
	}
	
	@Override
	public void paintBorder(Graphics g) {
	}

	private static class TimeSliderPreviewUI extends MetalToolTipUI {

		public static final Color BUBBLE_COLOR = new Color(0, 0, 0, 64);
		
		private JSketchModel model;
		private int displayTimeFrame = 0;
		private int[] arrowX = {50, 60, 70};
		
		public TimeSliderPreviewUI(JSketchModel model) {
			super();
			this.model = model;
		}
		
		@Override
		public void paint(Graphics g, JComponent c) {
			BufferedImage canvasCapture = new BufferedImage(model.getCanvasDimension().width, model.getCanvasDimension().height, BufferedImage.TYPE_INT_ARGB);
			Graphics2D buffer = canvasCapture.createGraphics();
			buffer.setColor(Color.WHITE);
			buffer.fillRect(0, 0, canvasCapture.getWidth(), canvasCapture.getHeight());
			for (JSketchStroke stroke : model.getStrokes(displayTimeFrame))
				paintStroke(buffer, stroke);
			buffer.dispose();

			g.setColor(BUBBLE_COLOR);
			g.fillRoundRect(0, 0, 120, 120, 20, 20);
			g.fillPolygon(arrowX, ARROW_Y, arrowX.length);

			double scaleFactor = 100d / Math.max(canvasCapture.getWidth(), canvasCapture.getHeight());
			AffineTransform transform = new AffineTransform();
			transform.setToScale(scaleFactor, scaleFactor);
			AffineTransformOp scaleOperation = new AffineTransformOp(transform, AffineTransformOp.TYPE_BICUBIC);
			BufferedImage scaled = new BufferedImage(100, 100, BufferedImage.TYPE_INT_ARGB);
			scaled = scaleOperation.filter(canvasCapture, scaled);

			int xOffset = canvasCapture.getWidth() >= canvasCapture.getHeight() ? 0 : (int)((canvasCapture.getHeight() - canvasCapture.getWidth()) * scaleFactor / 2);
			int yOffset = canvasCapture.getHeight() >= canvasCapture.getWidth() ? 0 : (int)((canvasCapture.getWidth() - canvasCapture.getHeight()) * scaleFactor / 2);
			g.drawImage(scaled, 10 + xOffset, 10 + yOffset, null);
		}

		private void paintStroke(Graphics2D g, JSketchStroke stroke) {
			if (!stroke.isVisible(displayTimeFrame))
				return;
			
			g.setStroke(DrawableCanvas.STANDARD_STROKE);
			g.setColor(stroke.getColor());

			g.draw(stroke.toGeneralPath(displayTimeFrame));
		}

		@Override
		public Dimension getPreferredSize(JComponent c) {
			return DIMENSION;
		}
	}
}
