/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.models;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import jsketch.ChangeEvent;
import jsketch.Main;
import jsketch.exceptions.InvalidTimeFrameException;

/**
 *
 * @author Nigel
 */
public class TimerModel extends AbstractModel {
	
	public enum State {
		PAUSE,
		PLAY,
		RECORD
	}

	private JSketchModel facade;
	private Timer timer;

	private State state = State.PAUSE;
	private int currentFrame = 0;

	public TimerModel(JSketchModel facade) {
		super(facade);
		this.facade = facade;
		timer = new Timer(Main.FRAME_INTERVAL, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				tick();
			}
		});
	}

	private void tick() {
		currentFrame++;
		if (state == State.PLAY && currentFrame >= facade.getLastMotionalFrame()) {
			currentFrame = facade.getLastMotionalFrame();
			setState(State.PAUSE);
		}
		else if (state == State.RECORD)
			facade.synchronizeTransformationFrame();

		updateAll(ChangeEvent.TIMEFRAME_UPDATE);
	}

	public int getCurrentFrame() {
		return currentFrame;
	}

	public void setCurrentFrame(int currentFrame) {
		if (currentFrame < 0)
			throw new InvalidTimeFrameException(currentFrame, 0);

		if (this.currentFrame == currentFrame)
			return;
		
		this.currentFrame = currentFrame;
		updateAll(ChangeEvent.TIMEFRAME_UPDATE);
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		if (this.state == state)
			return;

		if (this.state == State.PAUSE && state != State.PAUSE)
			timer.start();
		else if (this.state != State.PAUSE && state == State.PAUSE)
			timer.stop();

		this.state = state;
		updateAll(ChangeEvent.TIMEFRAME_UPDATE);
	}
}
