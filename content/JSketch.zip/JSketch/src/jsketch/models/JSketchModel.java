/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.models;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.io.File;
import jsketch.ChangeEvent;
import jsketch.dialogs.AbstractDialogRequest;
import jsketch.dialogs.AbstractDialogResponse;
import jsketch.project.JSketchSelection;
import jsketch.project.JSketchStroke;
import jsketch.project.TransformEvent;

/**
 * This is a facade for all other models.
 * The intuition behind this is to hide the model structures from views and controllers.
 *
 * @author Nigel
 */
public class JSketchModel extends AbstractModel {
	
	private ProjectModel projectModel;
	private CanvasModel canvasModel;
	private TimerModel timerModel;
	private DialogModel dialogModel;
	private HistoryModel historyModel;

	public JSketchModel() {
		timerModel = new TimerModel(this);
		projectModel = new ProjectModel(this);
		canvasModel = new CanvasModel(this);
		dialogModel = new DialogModel(this);
		historyModel = new HistoryModel(this);
	}
	
	public void start() {
		updateAll(ChangeEvent.INITIALIZED);
	}

	//
	// Canvas Model
	//

	public void drawPoint(Point point) {
		canvasModel.drawPoint(point);
	}

	public void drawSelection(Point point, boolean first) {
		canvasModel.drawSelection(point, first);
	}

	public void eraseStroke(Point point) {
		canvasModel.eraseStroke(point);
	}

	public void transformSelection(Point point, boolean first) {
		canvasModel.transformSelection(point, first);
	}

	public void drawPointEnd() {
		canvasModel.drawPointEnd();
	}

	public void drawSelectionEnd() {
		canvasModel.drawSelectionEnd();
	}

	public void transformSelectionEnd() {
		canvasModel.transformSelectionEnd();
	}

	public void setSelectionCenter(Point point) {
		canvasModel.setSelectionCenter(point);
	}
	
	public JSketchStroke getIncompleteStroke() {
		return canvasModel.getIncompleteStroke();
	}

	public JSketchSelection getSelection() {
		return canvasModel.getSelection();
	}

	public CanvasModel.Mode getCanvasMode() {
		return canvasModel.getCanvasMode();
	}

	public void setCanvasMode(CanvasModel.Mode canvasMode) {
		canvasModel.setCanvasMode(canvasMode);
	}

	public CanvasModel.TransformType getTransformType() {
		return canvasModel.getTransformType();
	}

	public void setTransformType(CanvasModel.TransformType transformType) {
		canvasModel.setTransformType(transformType);
	}

	public Color getCurrentColor() {
		return canvasModel.getCurrentColor();
	}

	public void setCurrentColor(Color color) {
		canvasModel.setCurrentColor(color);
	}

	public void extendFrame() {
		canvasModel.extendFrame();
	}

	public void extendFrameEnd() {
		canvasModel.extendFrameEnd();
	}

	public int getExtendFrameStart() {
		return canvasModel.getExtendFrameStart();
	}

	public void synchronizeTransformationFrame() {
		canvasModel.synchronizeTransformationFrame();
	}

	//
	// Project Model
	//

	public boolean isProjectChangedSinceLastSave() {
		return projectModel.isChangedSinceLastSave();
	}
	
	public void addStroke(JSketchStroke stroke) {
		projectModel.addStroke(stroke);
	}

	public void removeStroke(JSketchStroke stroke) {
		projectModel.removeStroke(stroke);
	}

	public void addTransformEvent(TransformEvent event) {
		projectModel.addTransformEvent(event);
	}

	public void removeTransformEvent(TransformEvent event) {
		projectModel.removeTransformEvent(event);
	}

	public void addTransformFrame(TransformEvent event, int timeFrame, Point point) {
		projectModel.addTransformFrame(event, timeFrame, point);
	}

	public void setStrokeEndFrame(JSketchStroke stroke, int endFrame) {
		projectModel.setStrokeEndFrame(stroke, endFrame);
	}

	public void notifyModification() {
		projectModel.notifyModification();
	}

	public Iterable<JSketchStroke> getStrokes(int timeFrame) {
		return projectModel.getStrokes(timeFrame);
	}
	
	public Iterable<JSketchStroke> getCurrentStrokes() {
		return projectModel.getStrokes(timerModel.getCurrentFrame());
	}

	public int getLastMotionalFrame() {
		return projectModel.getLastMotionalFrame();
	}

	public Dimension getCanvasDimension() {
		return projectModel.getCanvasDimension();
	}

	public File getProjectFile() {
		return projectModel.getProjectFile();
	}

	public Iterable<JSketchStroke> getAllStrokes() {
		return projectModel.getAllStrokes();
	}

	public Iterable<TransformEvent> getAllTransformEvents() {
		return projectModel.getAllEvents();
	}

	public void internalNewProject(int width, int height) {
		projectModel.internalNewProject(width, height);
	}

	public void internalSaveProject(File file) {
		projectModel.internalSaveProject(file);
	}

	public void internalLoadProject(File file) {
		projectModel.internalLoadProject(file);
	}

	public void internalExportProject(ProjectModel.ExportType type, File file) {
		projectModel.internalExportProject(type, file);
	}

	//
	// Timer Model
	//

	public int getCurrentFrame() {
		return timerModel.getCurrentFrame();
	}

	public void setCurrentFrame(int currentFrame) {
		timerModel.setCurrentFrame(currentFrame);
	}

	public TimerModel.State getTimerState() {
		return timerModel.getState();
	}
	
	public void setTimerState(TimerModel.State state) {
		timerModel.setState(state);
	}

	//
	// Dialog Model
	//

	public void closeApplication() {
		dialogModel.closeApplication();
	}

	public void newProject() {
		dialogModel.newProject();
	}

	public void saveProject(boolean saveAs) {
		dialogModel.saveProject(saveAs);
	}

	public void loadProject() {
		dialogModel.loadProject();
	}

	public void exportProject(ProjectModel.ExportType type) {
		dialogModel.exportProject(type);
	}

	public AbstractDialogRequest getDialogRequest() {
		return dialogModel.getDialogRequest();
	}

	public void dialogClosed(AbstractDialogResponse response) {
		dialogModel.dialogClosed(response);
	}

	//
	// History Model
	//

	public void undo() {
		historyModel.undo();
	}

	public void redo() {
		historyModel.redo();
	}

	public void clearHistory() {
		historyModel.clear();
	}

	public void executeRevertable(HistoryModel.Strategy strategy) {
		strategy.execute();
		historyModel.add(strategy);
	}

	public void registerRevertable(HistoryModel.Strategy strategy) {
		historyModel.add(strategy);
	}

	public boolean hasUndoEvents() {
		return historyModel.hasUndoEvents();
	}

	public boolean hasRedoEvents() {
		return historyModel.hasRedoEvents();
	}

	public String getNextUndoDescription() {
		return historyModel.getNextUndoDescription();
	}

	public String getNextRedoDescription() {
		return historyModel.getNextRedoDescription();
	}
}
