/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.models;

import java.io.File;
import jsketch.ChangeEvent;
import jsketch.dialogs.*;

/**
 *
 * @author Nigel
 */
public class DialogModel extends AbstractModel {
	
	private JSketchModel facade;
	private AbstractDialogRequest dialogRequest = null;
	private AbstractDialogStrategy dialogStrategy = null;

	public DialogModel(JSketchModel facade) {
		super(facade);
		this.facade = facade;
	}

	public void closeApplication() {
		if (!facade.isProjectChangedSinceLastSave())
			System.exit(0);
		
		dialogRequest = new ConfirmDialogRequest("Close", "Any unsaved progress will be lost. Would you like to save current project?", AbstractDialogRequest.Kind.SAVE_DONT_CANCEL);
		dialogStrategy = new ConfirmDialogStrategy() {

			@Override
			public void yes() {
				saveProject(false, new PostSaveAction() {

					@Override
					public void execute() {
						System.exit(0);
					}
				});
			}

			@Override
			public void no() {
				System.exit(0);
			}

			@Override
			public void cancel() {
			}
		};

		updateAll(ChangeEvent.NEW_DIALOG);
	}

	public void newProject() {
		if (!facade.isProjectChangedSinceLastSave()) {
			initiateNewProject();
			return;
		}
		
		dialogRequest = new ConfirmDialogRequest("New Project", "Any unsaved progress will be lost. Would you like to save before creating a new project?", AbstractDialogRequest.Kind.SAVE_DONT_CANCEL);
		dialogStrategy = new ConfirmDialogStrategy() {

			@Override
			public void yes() {
				saveProject(false, new PostSaveAction() {

					@Override
					public void execute() {
						initiateNewProject();
					}
				});
			}

			@Override
			public void no() {
				initiateNewProject();
			}

			@Override
			public void cancel() {
			}
		};

		updateAll(ChangeEvent.NEW_DIALOG);
	}

	private void initiateNewProject() {
		dialogRequest = new CanvasConfigurationRequest("New Project", AbstractDialogRequest.Kind.CANVAS_CONFIGURATION, 600, 400);
		dialogStrategy = new CanvasConfigurationStrategy() {

			@Override
			public void confirm(int width, int height) {
				facade.internalNewProject(width, height);
			}

			@Override
			public void cancel() {
			}
		};

		updateAll(ChangeEvent.NEW_DIALOG);
	}

	public void saveProject(boolean saveAs) {
		saveProject(saveAs, null);
	}

	private void saveProject(boolean saveAs, final PostSaveAction postSaveAction) {
		if (!saveAs && facade.getProjectFile() != null) {
			facade.internalSaveProject(facade.getProjectFile());
			return;
		}
		
		dialogRequest = new FileChooserRequest(saveAs ? "Save Project As" : "Save Project", "jsk", "JSketch Project File (*.jsk)", AbstractDialogRequest.Kind.SAVE_FILE);
		dialogStrategy = new FileChooserStrategy() {

			@Override
			public void confirm(File file) {
				facade.internalSaveProject(file);
				if (postSaveAction != null)
					postSaveAction.execute();
			}

			@Override
			public void cancel() {
			}
		};

		updateAll(ChangeEvent.NEW_DIALOG);
	}

	public void loadProject() {
		if (!facade.isProjectChangedSinceLastSave()) {
			initiateLoadProject();
			return;
		}
		
		dialogRequest = new ConfirmDialogRequest("New Project", "Any unsaved progress will be lost. Would you like to save before loading another project?", AbstractDialogRequest.Kind.SAVE_DONT_CANCEL);
		dialogStrategy = new ConfirmDialogStrategy() {

			@Override
			public void yes() {
				saveProject(false, new PostSaveAction() {

					@Override
					public void execute() {
						initiateLoadProject();
					}
				});
			}

			@Override
			public void no() {
				initiateLoadProject();
			}

			@Override
			public void cancel() {
			}
		};

		updateAll(ChangeEvent.NEW_DIALOG);
	}

	private void initiateLoadProject() {
		dialogRequest = new FileChooserRequest("Load Project", "jsk", "JSketch Project File (*.jsk)", AbstractDialogRequest.Kind.OPEN_FILE);
		dialogStrategy = new FileChooserStrategy() {

			@Override
			public void confirm(File file) {
				facade.internalLoadProject(file);
			}

			@Override
			public void cancel() {
			}
		};

		updateAll(ChangeEvent.NEW_DIALOG);
	}
	
	public void exportProject(final ProjectModel.ExportType type) {
		if (type == ProjectModel.ExportType.HTML)
			dialogRequest = new FileChooserRequest("Export HTML 5 Animation", "html", "HTML File (*.html)", AbstractDialogRequest.Kind.SAVE_FILE);
		else if (type == ProjectModel.ExportType.JSON)
			dialogRequest = new FileChooserRequest("Export Animation for Android", "jsa", "JSketch Animation File (*.jsa)", AbstractDialogRequest.Kind.SAVE_FILE);
		else
			return;

		dialogStrategy = new FileChooserStrategy() {

			@Override
			public void confirm(File file) {
				facade.internalExportProject(type, file);
			}

			@Override
			public void cancel() {
			}
		};

		updateAll(ChangeEvent.NEW_DIALOG);
	}

	public AbstractDialogRequest getDialogRequest() {
		return dialogRequest;
	}

	public void dialogClosed(AbstractDialogResponse response) {
		// Ignore if out of sync with controller
		if (response.getRequest() != dialogRequest)
			return;

		dialogStrategy.execute(response);
		dialogRequest = null;
		dialogStrategy = null;
	}

	
	private static interface PostSaveAction {
		public void execute();
	}
}
