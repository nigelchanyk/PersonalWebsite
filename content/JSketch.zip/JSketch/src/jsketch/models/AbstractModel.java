/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.models;

import java.util.LinkedList;
import jsketch.ChangeEvent;
import jsketch.IView;

/**
 *
 * @author Nigel
 */
public abstract class AbstractModel {
	
	private LinkedList<IView> observers = new LinkedList<>();
	private AbstractModel parentModel;

	public AbstractModel() {
	}

	public AbstractModel(AbstractModel parentModel) {
		this.parentModel = parentModel;
	}
	
	public void subscribe(IView observer) {
		if (!observers.contains(observer))
			observers.addLast(observer);
	}

	public void unsubscribe(IView observer) {
		observers.remove(observer);
	}

	protected void updateAll(ChangeEvent... events) {
		if (parentModel != null)
			parentModel.updateAll(events);

		for (IView observer : observers) {
			for (ChangeEvent event : events)
				observer.update(event);
		}
	}
	
}
