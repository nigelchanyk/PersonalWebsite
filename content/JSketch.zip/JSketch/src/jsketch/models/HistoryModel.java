/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.models;

import java.util.Stack;
import jsketch.ChangeEvent;

/**
 *
 * @author Nigel
 */
public class HistoryModel extends AbstractModel {
	
	private JSketchModel facade;
	private Stack<Strategy> undoStack = new Stack<>();
	private Stack<Strategy> redoStack = new Stack<>();
	
	public HistoryModel(JSketchModel facade) {
		super(facade);
		this.facade = facade;
	}

	public void add(Strategy strategy) {
		undoStack.push(strategy);
		redoStack.clear();
		updateAll(ChangeEvent.HISTORY_UPDATE);
	}

	public void undo() {
		if (undoStack.isEmpty())
			return;

		facade.setTimerState(TimerModel.State.PAUSE);
		Strategy strategy = undoStack.pop();
		strategy.rollback();
		redoStack.push(strategy);
		updateAll(ChangeEvent.HISTORY_UPDATE);
	}

	public void redo() {
		if (redoStack.isEmpty())
			return;

		facade.setTimerState(TimerModel.State.PAUSE);
		Strategy strategy = redoStack.pop();
		strategy.execute();
		undoStack.push(strategy);
		updateAll(ChangeEvent.HISTORY_UPDATE);
	}

	public void clear() {
		undoStack.clear();
		redoStack.clear();
		updateAll(ChangeEvent.HISTORY_UPDATE);
	}

	public boolean hasUndoEvents() {
		return !undoStack.isEmpty();
	}

	public boolean hasRedoEvents() {
		return !redoStack.isEmpty();
	}

	public String getNextUndoDescription() {
		if (undoStack.isEmpty())
			return null;
		return undoStack.peek().getDescription();
	}

	public String getNextRedoDescription() {
		if (redoStack.isEmpty())
			return null;
		return redoStack.peek().getDescription();
	}

	public abstract static class Strategy {

		public abstract void rollback();
		public abstract void execute();
		public abstract String getDescription();
		
	}
	
}
