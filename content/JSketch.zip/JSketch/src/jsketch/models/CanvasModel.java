/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.models;

import java.awt.Color;
import java.awt.Point;
import java.util.LinkedList;
import jsketch.ChangeEvent;
import jsketch.project.*;
import jsketch.utilities.MathHelper;

/**
 *
 * @author Nigel
 */
public class CanvasModel extends AbstractModel {

	public enum Mode {
		DRAW,
		SELECT,
		ERASE,
		TRANSFORM
	}

	public enum TransformType {
		TRANSLATE,
		ROTATE,
		SCALE
	}
	
	private JSketchModel facade;
	private Mode canvasMode = Mode.DRAW;
	private TransformType transformType = TransformType.TRANSLATE;
	private JSketchStroke currentStroke;
	private JSketchSelection currentSelection;
	private TransformEvent currentTransform;
	private Color currentColor = Color.BLACK;
	private Point lastPoint;
	private int extendFrameStart = -1;
	private int previousFrameStart = -1;

	public CanvasModel(JSketchModel facade) {
		super(facade);
		this.facade = facade;
		this.currentSelection = new JSketchSelection(facade.getCurrentFrame());
	}

	public Mode getCanvasMode() {
		return canvasMode;
	}

	public void setCanvasMode(Mode canvasMode) {
		this.canvasMode = canvasMode;
		if (canvasMode != Mode.DRAW)
			currentStroke = null;

		if (canvasMode != Mode.SELECT && canvasMode != Mode.TRANSFORM)
			currentSelection = new JSketchSelection(facade.getCurrentFrame());

		updateAll(ChangeEvent.CANVAS_UPDATE);
	}

	public void setSelectionCenter(Point point) {
		if (currentSelection != null) {
			currentSelection.setCenter(point, facade.getCurrentFrame());
			updateAll(ChangeEvent.CANVAS_UPDATE);
		}
	}

	public TransformType getTransformType() {
		return transformType;
	}

	public void setTransformType(TransformType transformType) {
		this.transformType = transformType;
	}
	
	public void drawPoint(Point point) {
		if (currentStroke == null)
			currentStroke = new JSketchStroke(facade.getCurrentFrame(), currentColor);
		else if (point.distanceSq(currentStroke.getLastPoint()) < 9)
			return;

		currentStroke.addPoint(point);
		updateAll(ChangeEvent.CANVAS_UPDATE);
	}

	public void drawSelection(Point point, boolean first) {
		if (first)
			currentSelection = new JSketchSelection(facade.getCurrentFrame());
		else if (point.distanceSq(currentSelection.getLastPoint()) < 9)
			return;

		currentSelection.addPoint(point);
		updateAll(ChangeEvent.CANVAS_UPDATE);
	}

	public void transformSelection(Point point, boolean first) {
		if (currentTransform == null || first) {
			switch (transformType) {
				case TRANSLATE:
					currentTransform = new TranslateEvent(facade.getCurrentFrame(), point);
					break;
				case ROTATE:
					currentTransform = new RotateEvent(facade.getCurrentFrame(), point, currentSelection.getCenter(facade.getCurrentFrame()));
					break;
				case SCALE:
					currentTransform = new ScaleEvent(facade.getCurrentFrame(), point, currentSelection.getCenter(facade.getCurrentFrame()));
					break;
			}

			for (JSketchStroke stroke : currentSelection.getSelected())
				stroke.addTransform(currentTransform);
			currentSelection.addTransform(currentTransform);

			facade.addTransformEvent(currentTransform);
			facade.setTimerState(TimerModel.State.RECORD);
		}
		else
			facade.addTransformFrame(currentTransform, facade.getCurrentFrame(), point);

		lastPoint = point;

		// No update is required since TimerModel will update every frame
	}

	public void synchronizeTransformationFrame() {
		if (currentTransform == null || lastPoint == null)
			return;
		if (currentTransform.getEndFrame() >= facade.getCurrentFrame())
			return;

		facade.addTransformFrame(currentTransform, facade.getCurrentFrame(), lastPoint);
	}

	public void eraseStroke(Point point) {
		for (JSketchStroke stroke : facade.getCurrentStrokes()) {
			if (stroke.intersectsEdge(point, 1.5, facade.getCurrentFrame())) {
				facade.executeRevertable(new EraseStrokeStrategy(facade, stroke, facade.getCurrentFrame()));
				return;
			}
		}
	}

	public void drawPointEnd() {
		if (currentStroke == null)
			return;
		
		if (currentStroke.getPointsCount() > 1)
			facade.executeRevertable(new AddStrokeStrategy(facade, currentStroke));

		currentStroke = null;
	}

	public void drawSelectionEnd() {
		if (currentSelection.getPointsCount() == 0)
			return;
		currentSelection.addPoint(currentSelection.getFirstPoint());
		currentSelection.select(facade.getCurrentStrokes(), facade.getCurrentFrame());
		if (currentSelection.getSelectedCount() == 0)
			currentSelection = new JSketchSelection(facade.getCurrentFrame());
		
		updateAll(ChangeEvent.CANVAS_UPDATE);
	}

	public void transformSelectionEnd() {
		if (currentTransform == null || currentSelection.getSelectedCount() == 0)
			return;

		facade.setTimerState(TimerModel.State.PAUSE);

		LinkedList<JSketchPath> paths = new LinkedList<>();
		for (JSketchStroke stroke : currentSelection.getSelected())
			paths.addLast(stroke);
		paths.addLast(currentSelection);
		
		facade.registerRevertable(new AddTransformStrategy(facade, paths, currentTransform));
		
		facade.setCurrentFrame(currentTransform.getEndFrame());
		currentTransform = null;
		lastPoint = null;
		updateAll(ChangeEvent.CANVAS_UPDATE);
	}

	public JSketchStroke getIncompleteStroke() {
		return currentStroke;
	}

	public JSketchSelection getSelection() {
		return currentSelection;
	}

	public Color getCurrentColor() {
		return currentColor;
	}

	public void setCurrentColor(Color currentColor) {
		this.currentColor = currentColor;
		updateAll(ChangeEvent.COLOR_UPDATE);
	}

	public int getExtendFrameStart() {
		return extendFrameStart;
	}

	public void extendFrame() {
		if (extendFrameStart == -1) {
			extendFrameStart = facade.getCurrentFrame();
			previousFrameStart = extendFrameStart;
		}
		else {
			int start = Math.min(facade.getCurrentFrame(), previousFrameStart);
			int end = Math.max(facade.getCurrentFrame(), previousFrameStart);
			if (facade.getCurrentFrame() < extendFrameStart)
				start = extendFrameStart;

			if (start == end) {
				previousFrameStart = Math.max(extendFrameStart, facade.getCurrentFrame());
				return;
			}

			ExtendFrameStrategy strategy = new ExtendFrameStrategy(facade, start, end, facade.getAllStrokes(), facade.getAllTransformEvents());
			if (facade.getCurrentFrame() > previousFrameStart) {
				// Extend
				strategy.execute();
			}
			else {
				// Contract
				strategy.rollback();
			}
			previousFrameStart = Math.max(extendFrameStart, facade.getCurrentFrame());

			// the strategy already sends an update, therefore, an update is not required
		}
	}

	public void extendFrameEnd() {
		if (facade.getCurrentFrame() <= extendFrameStart) {
			extendFrameStart = -1;
			return;
		}

		ExtendFrameStrategy strategy = new ExtendFrameStrategy(facade, extendFrameStart, facade.getCurrentFrame(), facade.getAllStrokes(), facade.getAllTransformEvents());
		facade.registerRevertable(strategy);

		extendFrameStart = -1;
		updateAll(ChangeEvent.TIMEFRAME_UPDATE);
	}



	private static class AddStrokeStrategy extends HistoryModel.Strategy {

		private JSketchStroke stroke;
		private JSketchModel facade;
		
		public AddStrokeStrategy(JSketchModel facade, JSketchStroke stroke) {
			this.facade = facade;
			this.stroke = stroke;
		}

		@Override
		public void rollback() {
			facade.removeStroke(stroke);
		}

		@Override
		public void execute() {
			facade.addStroke(stroke);
		}

		@Override
		public String getDescription() {
			return "Draw Stroke at " + MathHelper.toTime(stroke.getStartFrame());
		}

	}

	private static class EraseStrokeStrategy extends HistoryModel.Strategy {

		private JSketchStroke stroke;
		private JSketchModel facade;
		private int timeFrame;
		private int originalEndFrame;
		
		public EraseStrokeStrategy(JSketchModel facade, JSketchStroke stroke, int timeFrame) {
			this.facade = facade;
			this.stroke = stroke;
			this.timeFrame = timeFrame;
			this.originalEndFrame = stroke.getEndFrame();
		}

		@Override
		public void rollback() {
			if (timeFrame == stroke.getStartFrame())
				facade.addStroke(stroke);
			else
				facade.setStrokeEndFrame(stroke, originalEndFrame);
		}

		@Override
		public void execute() {
			if (timeFrame == stroke.getStartFrame())
				facade.removeStroke(stroke);
			else
				facade.setStrokeEndFrame(stroke, timeFrame - 1);
		}

		@Override
		public String getDescription() {
			return "Erase Stroke at " + MathHelper.toTime(timeFrame);
		}
		
	}

	private static class AddTransformStrategy extends HistoryModel.Strategy {

		private Iterable<JSketchPath> strokes;
		private TransformEvent event;
		private JSketchModel facade;

		public AddTransformStrategy(JSketchModel facade, Iterable<JSketchPath> strokes, TransformEvent event) {
			this.facade = facade;
			this.strokes = strokes;
			this.event = event;
		}
		
		@Override
		public void rollback() {
			for (JSketchPath stroke : strokes)
				stroke.removeTransform(event);

			facade.removeTransformEvent(event);
		}

		@Override
		public void execute() {
			for (JSketchPath stroke : strokes)
				stroke.addTransform(event);

			facade.addTransformEvent(event);
		}

		@Override
		public String getDescription() {
			return "Transform Stroke(s) from " + MathHelper.toTime(event.getStartFrame()) + " to " + MathHelper.toTime(event.getEndFrame());
		}
		
	}

	private static class ExtendFrameStrategy extends HistoryModel.Strategy {

		private Iterable<JSketchStroke> paths;
		private Iterable<TransformEvent> events;
		private int startFrame;
		private int endFrame;
		private JSketchModel model;

		public ExtendFrameStrategy(JSketchModel model, int startFrame, int endFrame, Iterable<JSketchStroke> paths, Iterable<TransformEvent> events) {
			this.model = model;
			this.paths = paths;
			this.events = events;
			this.startFrame = startFrame;
			this.endFrame = endFrame;
		}

		@Override
		public void rollback() {
			for (JSketchPath path : paths) {
				if (path.getEndFrame() != Integer.MAX_VALUE)
					path.setEndFrame(path.getEndFrame() - endFrame + startFrame);
			}

			for (TransformEvent event : events)
				event.removeFrames(startFrame, endFrame - startFrame);

			model.notifyModification();
		}

		@Override
		public void execute() {
			for (JSketchPath path : paths) {
				if (path.getEndFrame() != Integer.MAX_VALUE)
					path.setEndFrame(path.getEndFrame() + endFrame - startFrame);
			}

			for (TransformEvent event : events)
				event.duplicateFrames(startFrame, endFrame - startFrame);

			model.notifyModification();
		}

		@Override
		public String getDescription() {
			return "Extend frame at " + MathHelper.toTime(startFrame) + " until " + MathHelper.toTime(endFrame); 
		}

	}

}
