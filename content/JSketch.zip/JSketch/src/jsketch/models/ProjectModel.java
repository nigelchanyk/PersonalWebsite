/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.models;

import java.awt.Dimension;
import java.awt.Point;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import jsketch.ChangeEvent;
import jsketch.project.JSketchProject;
import jsketch.project.JSketchStroke;
import jsketch.project.TransformEvent;
import jsketch.utilities.ProjectExporter;
import jsketch.utilities.ProjectSerializer;

/**
 *
 * @author Nigel
 */
public class ProjectModel extends AbstractModel {

	public enum ExportType {
		HTML,
		JSON
	}
	
	private JSketchModel facade;
	private JSketchProject project = new JSketchProject();
	private int lastMotionalFrame = 0;
	private boolean changedSinceLastSave = false;
	private File projectFile = null;
	private LinkedList<TransformEvent> transforms = new LinkedList<>();

	public ProjectModel(JSketchModel facade) {
		super(facade);
		this.facade = facade;
	}

	public boolean isChangedSinceLastSave() {
		return changedSinceLastSave;
	}

	public void addTransformEvent(TransformEvent event) {
		changedSinceLastSave = true;
		setLastMotionalFrame();
		transforms.addLast(event);
		updateAll(ChangeEvent.CANVAS_UPDATE);
	}

	public void removeTransformEvent(TransformEvent event) {
		changedSinceLastSave = true;
		setLastMotionalFrame();
		transforms.remove(event);
		updateAll(ChangeEvent.CANVAS_UPDATE);
	}

	public void addTransformFrame(TransformEvent event, int timeFrame, Point point) {
		event.addTransform(point, timeFrame);
		changedSinceLastSave = true;
		setLastMotionalFrame();
	}

	public void addStroke(JSketchStroke stroke) {
		changedSinceLastSave = true;
		project.addStroke(stroke);
		setLastMotionalFrame();
		updateAll(ChangeEvent.CANVAS_UPDATE);
	}

	public void removeStroke(JSketchStroke stroke) {
		changedSinceLastSave = true;
		project.removeStroke(stroke);
		setLastMotionalFrame();
		updateAll(ChangeEvent.CANVAS_UPDATE);
	}

	public void setStrokeEndFrame(JSketchStroke stroke, int endFrame) {
		changedSinceLastSave = true;
		stroke.setEndFrame(endFrame);
		setLastMotionalFrame();
		updateAll(ChangeEvent.CANVAS_UPDATE);
	}

	public int getLastMotionalFrame() {
		return lastMotionalFrame;
	}

	public Iterable<TransformEvent> getAllEvents() {
		return transforms;
	}

	private void setLastMotionalFrame() {
		lastMotionalFrame = project.calculateLastMotionalFrame();
	}

	public Dimension getCanvasDimension() {
		return project.getDimension();
	}

	public Iterable<JSketchStroke> getStrokes(int frame) {
		LinkedList<JSketchStroke> strokes = new LinkedList<>();
		for (JSketchStroke stroke : project.getAllStrokes()) {
			if (stroke.getStartFrame() <= frame && stroke.getEndFrame() >= frame)
				strokes.addLast(stroke);
		}

		return strokes;
	}

	public Iterable<JSketchStroke> getAllStrokes() {
		return project.getAllStrokes();
	}

	public File getProjectFile() {
		return projectFile;
	}

	public void internalNewProject(int width, int height) {
		project = new JSketchProject(width, height);
		projectFile = null;
		changedSinceLastSave = false;

		setLastMotionalFrame();
		facade.clearHistory();
		facade.setCanvasMode(CanvasModel.Mode.DRAW);
		facade.setTimerState(TimerModel.State.PAUSE);
		facade.setCurrentFrame(0);

		updateAll(ChangeEvent.PROJECT_CHANGED);
	}

	public void internalSaveProject(File file) {
		try {

			ProjectSerializer.save(project, file);
			this.projectFile = file;
			changedSinceLastSave = false;
		} catch (IOException e) {
			e.printStackTrace(System.err);
		}
	}

	public void internalLoadProject(File file) {
		try {
			project = ProjectSerializer.load(file);
			projectFile = file;
			changedSinceLastSave = false;

			setLastMotionalFrame();
			facade.clearHistory();
			facade.setCanvasMode(CanvasModel.Mode.DRAW);
			facade.setTimerState(TimerModel.State.PAUSE);
			facade.setCurrentFrame(0);

			updateAll(ChangeEvent.PROJECT_CHANGED);
		} catch (IOException e) {
			e.printStackTrace(System.err);
		} catch (ClassNotFoundException e) {
		}
	}

	public void internalExportProject(ExportType type, File file) {
		try {
			if (type == ExportType.HTML)
				ProjectExporter.exportHtml(project, file);
			else if (type == ExportType.JSON)
				ProjectExporter.exportJson(project, file);
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
	}

	public void notifyModification() {
		changedSinceLastSave = true;
		setLastMotionalFrame();
		updateAll(ChangeEvent.CANVAS_UPDATE);
	}

}
