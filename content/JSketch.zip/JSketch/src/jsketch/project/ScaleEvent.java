/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.project;

import java.awt.Point;
import java.awt.geom.AffineTransform;

/**
 *
 * @author Nigel
 */
public class ScaleEvent extends TransformEvent {
	
	private Point center;
	private double refDistanceSq;
	
	public ScaleEvent(int startFrame, Point origin, Point center) {
		super(startFrame, origin);
		this.center = center;
		refDistanceSq = center.distanceSq(origin);
		if (refDistanceSq == 0)
			refDistanceSq = 1;
	}

	@Override
	protected AffineTransform createTransform(Point point, int timeframe) {
		AffineTransform scale = new AffineTransform();
		scale.setToTranslation(center.x, center.y);
		double factor = center.distanceSq(point) / refDistanceSq;
		scale.scale(factor, factor);
		scale.translate(-center.x, -center.y);
		return scale;
	}
	
}
