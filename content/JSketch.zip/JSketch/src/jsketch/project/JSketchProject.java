/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.project;

import java.awt.Dimension;
import java.awt.Point;
import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map.Entry;
import jsketch.json.JSONArray;
import jsketch.json.JSONObject;
import jsketch.json.JSONSerializable;
import jsketch.json.JSONType;
import jsketch.utilities.ProjectExporter;

/**
 *
 * @author Nigel
 */
public class JSketchProject implements Serializable, JSONSerializable {
	
	private LinkedList<JSketchStroke> strokes = new LinkedList<>();
	private Dimension dimension;

	public JSketchProject() {
		dimension = new Dimension(600, 400);
	}

	public JSketchProject(int width, int height) {
		dimension = new Dimension(width, height);
	}

	public void addStroke(JSketchStroke stroke) {
		strokes.addLast(stroke);
	}

	public void removeStroke(JSketchStroke stroke) {
		strokes.remove(stroke);
	}

	public Dimension getDimension() {
		return dimension;
	}

	public int calculateLastMotionalFrame() {
		int lastFrame = 0;
		for (JSketchStroke stroke : strokes) {
			lastFrame = Math.max(stroke.getStartFrame(), lastFrame);
			lastFrame = Math.max(stroke.getLastMotionalFrame(), lastFrame);
		}

		return lastFrame;
	}

	public Iterable<JSketchStroke> getAllStrokes() {
		return strokes;
	}

	@Override
	public JSONType toJSON() {
		JSONObject obj = new JSONObject();
		obj.put("dimension", ProjectExporter.serializeDimension(dimension));
		obj.put("lastFrame", calculateLastMotionalFrame());
		
		HashMap<TransformEvent, Integer> eventMapper = new HashMap<>();

		JSONArray strokeArray = new JSONArray();
		for (JSketchStroke stroke : strokes)
			strokeArray.add(serializeStroke(eventMapper, stroke));
		obj.put("strokes", strokeArray);

		JSONObject eventHash = new JSONObject();
		for (Entry<TransformEvent, Integer> pair : eventMapper.entrySet()) {
			// In JSON, we map ID to event instead of event to ID
			eventHash.put(pair.getValue().toString(), pair.getKey().toJSON());
		}
		obj.put("events", eventHash);
		
		return obj;
	}

	private JSONObject serializeStroke(HashMap<TransformEvent, Integer> eventMapper, JSketchStroke stroke) {
		JSONObject obj = new JSONObject();
		obj.put("startFrame", stroke.getStartFrame());
		obj.put("endFrame", stroke.getEndFrame());

		JSONArray pointArray = new JSONArray();
		for (Point point : stroke.getRawPointsIterable())
			pointArray.add(ProjectExporter.serializePoint(point));
		obj.put("points", pointArray);

		JSONArray transformArray = new JSONArray();
		for (RelativeTransform transform : stroke.getRelativeTransformIterable())
			transformArray.add(serializeRelativeTransform(eventMapper, transform));
		obj.put("transforms", transformArray);

		obj.put("color", ProjectExporter.serializeColor(stroke.getColor()));
		
		return obj;
	}

	private JSONObject serializeRelativeTransform(HashMap<TransformEvent, Integer> eventMapper, RelativeTransform transform) {
		JSONObject obj = new JSONObject();
		obj.put("offset", ProjectExporter.serializeTransform(transform.getOffset()));
		obj.put("endFrame", transform.getEndFrame());
		obj.put("transformPriority", transform.getTransformPriority());
		
		int id = eventMapper.size();
		if (eventMapper.containsKey(transform.getEvent()))
			id = eventMapper.get(transform.getEvent());
		else
			eventMapper.put(transform.getEvent(), id);

		obj.put("event", id);
		return obj;
	}

}
