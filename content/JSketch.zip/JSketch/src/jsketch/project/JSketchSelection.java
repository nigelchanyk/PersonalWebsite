/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.project;

import java.awt.Point;
import java.awt.geom.GeneralPath;
import java.awt.geom.NoninvertibleTransformException;
import java.util.LinkedList;

/**
 *
 * @author Nigel
 */
public class JSketchSelection extends JSketchPath {
	
	private Point center = new Point();
	private LinkedList<JSketchStroke> selectedStrokes = new LinkedList<>();

	public JSketchSelection(int startFrame) {
		super(startFrame);
	}
	
	public void select(Iterable<JSketchStroke> strokes, int timeFrame) {
		Point min = new Point(Integer.MAX_VALUE, Integer.MAX_VALUE);
		Point max = new Point(Integer.MIN_VALUE, Integer.MIN_VALUE);
		
		selectedStrokes.clear();
		GeneralPath path = toGeneralPath(timeFrame);
		path.closePath();

		SEARCH:
		for (JSketchStroke stroke : strokes) {
			if (!stroke.isVisible(timeFrame))
				continue;

			for (Point point : stroke.getPointsIterable(timeFrame)) {
				if (!path.contains(point))
					continue SEARCH;
			}
			// Unreachable unless entire stroke is within selection
			selectedStrokes.addLast(stroke);

			for (Point point : stroke.getPointsIterable(timeFrame)) {
				min.x = Math.min(point.x, min.x);
				min.y = Math.min(point.y, min.y);
				max.x = Math.max(point.x, max.x);
				max.y = Math.max(point.y, max.y);
			}
		}

		if (!selectedStrokes.isEmpty()) {
			center.x = (min.x + max.x) / 2;
			center.y = (min.y + max.y) / 2;
		}
	}

	public boolean isSelected(JSketchStroke stroke) {
		return selectedStrokes.contains(stroke);
	}

	public Iterable<JSketchStroke> getSelected() {
		return selectedStrokes;
	}

	public int getSelectedCount() {
		return selectedStrokes.size();
	}

	public boolean isSelected(Point point, int timeFrame) {
		if (selectedStrokes.isEmpty() || !isVisible(timeFrame))
			return false;

		GeneralPath path = toGeneralPath(timeFrame);
		path.closePath();

		return path.contains(point);
	}

	public Point getCenter(int timeframe) {
		if (selectedStrokes.size() == 0)
			return null;
		Point transformedCenter = new Point();
		getOffset(timeframe).transform(center, transformedCenter);
		return transformedCenter;
	}

	public void setCenter(Point center, int timeframe) {
		try {
			Point inverseTransformedCenter = new Point();
			getOffset(timeframe).createInverse().transform(center, inverseTransformedCenter);
			this.center = inverseTransformedCenter;
		} catch (NoninvertibleTransformException ex) {
			ex.printStackTrace(System.err);
		}
	}

}
