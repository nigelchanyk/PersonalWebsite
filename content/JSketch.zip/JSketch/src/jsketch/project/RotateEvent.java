/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.project;

import java.awt.Point;
import java.awt.geom.AffineTransform;

/**
 *
 * @author Nigel
 */
public class RotateEvent extends TransformEvent {
	
	private Point center;
	private double refAngle;
	
	public RotateEvent(int startFrame, Point origin, Point center) {
		super(startFrame, origin);
		this.center = center;
		this.refAngle = Math.atan2(origin.y - center.y, origin.x - center.x);
	}

	@Override
	protected AffineTransform createTransform(Point point, int timeframe) {
		AffineTransform rotation = new AffineTransform();
		rotation.setToTranslation(center.x, center.y);
		rotation.rotate(Math.atan2(point.y - center.y, point.x - center.x) - refAngle);
		rotation.translate(-center.x, -center.y);
		return rotation;
	}
	
}
