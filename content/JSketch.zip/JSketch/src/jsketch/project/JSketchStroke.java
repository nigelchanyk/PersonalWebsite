/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.project;

import java.awt.Color;

/**
 *
 * @author Nigel
 */
public class JSketchStroke extends JSketchPath {
	
	private Color color;

	public JSketchStroke(int startFrame, Color color) {
		super(startFrame);
		this.color = color;
	}


	public Color getColor() {
		return color;
	}


}
