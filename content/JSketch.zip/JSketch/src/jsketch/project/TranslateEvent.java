/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.project;

import java.awt.Point;
import java.awt.geom.AffineTransform;

/**
 *
 * @author Nigel
 */
public class TranslateEvent extends TransformEvent {
	
	public TranslateEvent(int startFrame, Point origin) {
		super(startFrame, origin);
	}

	@Override
	protected AffineTransform createTransform(Point point, int timeframe) {
		AffineTransform translation = new AffineTransform();
		translation.setToTranslation(point.x - origin.x, point.y - origin.y);
		return translation;
	}
	
}
