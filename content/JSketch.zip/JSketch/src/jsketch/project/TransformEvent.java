/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.project;

import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.io.Serializable;
import java.util.ArrayList;
import jsketch.exceptions.InvalidTimeFrameException;
import jsketch.json.JSONArray;
import jsketch.json.JSONObject;
import jsketch.json.JSONSerializable;
import jsketch.json.JSONType;
import jsketch.utilities.ProjectExporter;

/**
 *
 * @author Nigel
 */
public abstract class TransformEvent implements Serializable, JSONSerializable {
	
	protected Point origin;

	private int startFrame;
	private ArrayList<AffineTransform> transforms = new ArrayList<>();

	public TransformEvent(int startFrame, Point origin) {
		this.startFrame = startFrame;
		this.origin = origin;
		transforms.add(new AffineTransform());
		transforms.add(new AffineTransform());
	}

	public int getStartFrame() {
		return startFrame;
	}

	public void duplicateFrames(int start, int length) {
		int index = start - startFrame;
		if (index < 0) {
			startFrame += length;
			return;
		}

		if (index >= transforms.size())
			return;

		for (int i = 0; i < length; ++i) {
			transforms.add(index, transforms.get(index));
		}
	}

	public void removeFrames(int start, int length) {
		int index = start - startFrame;
		if (index < 0) {
			startFrame -= length;
			return;
		}
		
		if (index >= transforms.size())
			return;

		for (int i = 0; i < length; ++i)
			transforms.remove(index);
	}

	public void addTransform(Point point, int timeframe) {
		AffineTransform offset = createTransform(point, timeframe);

		if (timeframe < startFrame)
			throw new InvalidTimeFrameException(timeframe, startFrame);

		// Replace frame if already exist
		if (timeframe < getEndFrame()) {
			return;
		}

		// Setting last frame
		if (timeframe == getEndFrame()) {
			transforms.set(timeframe - startFrame, offset);
			// Extend one frame
			transforms.add(offset);
			return;
		}

		// Fill in time gap if exist
		while (timeframe - 1 > getEndFrame())
			transforms.add(transforms.get(transforms.size() - 1));

		// Set actual frame
		transforms.add(offset);
		// Extend one frame
		transforms.add(offset);
	}

	public AffineTransform getTransform(int timeframe) {
		int index = timeframe - startFrame;
		if (index < 0)
			throw new InvalidTimeFrameException(timeframe, startFrame);
			
		if (index >= transforms.size())
			return transforms.isEmpty() ? new AffineTransform() : new AffineTransform(transforms.get(transforms.size() - 1));

		return new AffineTransform(transforms.get(timeframe - startFrame));
	}

	public int getEndFrame() {
		return startFrame + transforms.size() - 1;
	}

	@Override
	public JSONType toJSON() {
		JSONObject obj = new JSONObject();
		obj.put("startFrame", startFrame);
		obj.put("origin", ProjectExporter.serializePoint(origin));

		JSONArray array = new JSONArray();
		for (AffineTransform transform : transforms)
			array.add(ProjectExporter.serializeTransform(transform));

		obj.put("transforms", array);
		
		return obj;
	}

	protected abstract AffineTransform createTransform(Point point, int timeframe);

}
