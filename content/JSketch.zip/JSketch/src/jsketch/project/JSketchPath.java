/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.project;

import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author Nigel
 */
public abstract class JSketchPath implements Serializable {
	
	protected int startFrame;
	protected int endFrame = Integer.MAX_VALUE;
	protected LinkedList<Point> points = new LinkedList<>();
	private LinkedList<RelativeTransform> transforms = new LinkedList<>();
	private int transformId = 0;

	public JSketchPath(int startFrame) {
		this.startFrame = startFrame;
	}
	
	public void addPoint(Point point) {
		points.addLast(point);
	}

	public int getEndFrame() {
		return endFrame;
	}

	public int getLastMotionalFrame() {
		if (endFrame < Integer.MAX_VALUE)
			return endFrame;

		int lastFrame = 0;
		for (RelativeTransform transform : transforms)
			lastFrame = Math.max(transform.getEndFrame(), lastFrame);

		return lastFrame;
	}

	public int getStartFrame() {
		return startFrame;
	}

	public void setEndFrame(int endFrame) {
		this.endFrame = endFrame;
	}

	public boolean isVisible(int timeFrame) {
		return timeFrame >= startFrame && timeFrame <= endFrame;
	}

	public boolean intersectsEdge(Point point, double threshold, int timeFrame) {
		double thresholdSq = threshold * threshold;

		if (points.isEmpty())
			return false;
		if (points.size() == 1)
			return getPointsIterable(timeFrame).iterator().next().distanceSq(point) < thresholdSq;
		
		Iterator<Point> itr = getPointsIterable(timeFrame).iterator();
		Point previous = itr.next();
		
		while (itr.hasNext()) {
			Point current = itr.next();
			Line2D line = new Line2D.Double(previous, current);
			if (line.ptSegDistSq(point) < thresholdSq)
				return true;
		}

		return false;
	}

	public Iterable<Point> getRawPointsIterable() {
		return points;
	}

	public Iterable<RelativeTransform> getRelativeTransformIterable() {
		return transforms;
	}

	public Iterable<Point> getPointsIterable(int timeFrame) {
		AffineTransform offset = getOffset(timeFrame);
		LinkedList<Point> transformedPoints = new LinkedList<>();
		for (Point point : points) {
			Point transformedPoint = new Point();
			offset.transform(point, transformedPoint);
			transformedPoints.addLast(transformedPoint);
		}
		
		return transformedPoints;
	}

	public int getPointsCount() {
		return points.size();
	}

	public Point getFirstPoint() {
		return points.isEmpty() ? null : points.getFirst();
	}

	public Point getLastPoint() {
		return points.isEmpty() ? null : points.getLast();
	}

	protected AffineTransform getOffset(int timeframe) {
		int offsetPriority = -1;
		int lastFrame = -1;
		AffineTransform offset = new AffineTransform();
		for (RelativeTransform transform : transforms) {
			if (timeframe < transform.getStartFrame())
				continue;

			if (timeframe > transform.getEndFrame()) {
				// Offset is determined by the last frame of all transformations given timeframe is not within any transform range
				if (offsetPriority == -1 && lastFrame < transform.getEndFrame()) {
					offset = transform.getTransform(transform.getEndFrame());
					lastFrame = transform.getEndFrame();
				}
			}
			else if (offsetPriority < transform.getTransformPriority()) {
				// Offset is determined by the transfrom that covers the given timeframe with the highest priority
				offset = transform.getTransform(timeframe);
				offsetPriority = transform.getTransformPriority();
			}
		}
		return offset;
	}

	public void addTransform(TransformEvent event) {
		transforms.add(new RelativeTransform(event, getOffset(event.getStartFrame()), transformId++));
	}

	public void removeTransform(TransformEvent event) {
		Iterator<RelativeTransform> itr = transforms.iterator();
		while (itr.hasNext()) {
			if (itr.next().getEvent() == event) {
				itr.remove();
				return;
			}
		}
	}

	public GeneralPath toGeneralPath(int timeFrame) {
		GeneralPath path = null;
		for (Point point : getPointsIterable(timeFrame)) {
			if (path == null) {
				path = new GeneralPath(GeneralPath.WIND_NON_ZERO, points.size());
				path.moveTo(point.x, point.y);
			}
			else
				path.lineTo(point.x, point.y);
		}
		return path;
	}

}
