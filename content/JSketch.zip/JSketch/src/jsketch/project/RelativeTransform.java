/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jsketch.project;

import java.awt.geom.AffineTransform;
import java.io.Serializable;

/**
 *
 * @author Nigel
 */
public class RelativeTransform implements Serializable {
	
	private TransformEvent event;
	private AffineTransform offset;
	private int transformPriority;

	public RelativeTransform(TransformEvent event, AffineTransform offset, int transformPriority) {
		this.event = event;
		this.offset = offset;
		this.transformPriority = transformPriority;
	}
	
	public TransformEvent getEvent() {
		return event;
	}

	public AffineTransform getTransform(int timeframe) {
		AffineTransform transform = event.getTransform(timeframe);
		transform.concatenate(offset);
		return transform;
	}

	public int getStartFrame() {
		return event.getStartFrame();
	}

	public int getEndFrame() {
		return event.getEndFrame();
	}

	public int getTransformPriority() {
		return transformPriority;
	}

	public AffineTransform getOffset() {
		return new AffineTransform(offset);
	}

}
